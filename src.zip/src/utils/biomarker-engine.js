// Biomarker Analysis Engine — Evidence-based health signal extraction
// Modules: rPPG Heart Rate, Face Analysis, Eye Analysis, Skin Lesion Triage, Body Composition

import { QualityGate } from './camera-system.js';

// ═══════════════════════════════════════════════════════
//  1) rPPG HEART RATE — Extract HR from face video
// ═══════════════════════════════════════════════════════

export class RPPGEngine {
    constructor() {
        this.buffer = [];          // { r, g, b, timestamp }
        this.bufferSize = 300;     // ~10 seconds at 30fps
        this.isRecording = false;
        this.onProgress = null;
        this.onResult = null;
    }

    start(durationMs = 15000) {
        this.buffer = [];
        this.isRecording = true;
        this._startTime = performance.now();
        this._duration = durationMs;
    }

    addFrame(imageData) {
        if (!this.isRecording) return;

        const elapsed = performance.now() - this._startTime;
        const progress = Math.min(1, elapsed / this._duration);
        if (this.onProgress) this.onProgress(progress);

        // Extract avg RGB from forehead ROI (top 30-50%, center 40-60%)
        const roi = this._extractForeheadROI(imageData);
        this.buffer.push({ ...roi, timestamp: performance.now() });

        if (this.buffer.length > this.bufferSize) this.buffer.shift();

        if (elapsed >= this._duration) {
            this.isRecording = false;
            const result = this.analyze();
            if (this.onResult) this.onResult(result);
            return result;
        }
        return null;
    }

    _extractForeheadROI(imageData) {
        const { data, width, height } = imageData;
        // Forehead region: top 20-40% of image, center 30-70%
        const y1 = Math.floor(height * 0.2);
        const y2 = Math.floor(height * 0.4);
        const x1 = Math.floor(width * 0.3);
        const x2 = Math.floor(width * 0.7);

        let sumR = 0, sumG = 0, sumB = 0, count = 0;
        for (let y = y1; y < y2; y += 2) {
            for (let x = x1; x < x2; x += 2) {
                const i = (y * width + x) * 4;
                sumR += data[i]; sumG += data[i + 1]; sumB += data[i + 2];
                count++;
            }
        }

        return { r: sumR / count, g: sumG / count, b: sumB / count };
    }

    analyze() {
        if (this.buffer.length < 60) {
            return { hr: 0, hrv: 0, confidence: 0, error: 'Insufficient frames' };
        }

        // Use green channel (strongest pulse signal in skin)
        const signal = this.buffer.map(f => f.g);
        const timestamps = this.buffer.map(f => f.timestamp);

        // Calculate sample rate
        const duration = (timestamps[timestamps.length - 1] - timestamps[0]) / 1000;
        const sampleRate = signal.length / duration;

        // Detrend (remove linear trend)
        const detrended = this._detrend(signal);

        // Bandpass filter: 0.7-3.5 Hz (42-210 BPM)
        const filtered = this._bandpassFilter(detrended, sampleRate, 0.7, 3.5);

        // Find dominant frequency via autocorrelation
        const { hr, confidence: freqConfidence } = this._findHeartRate(filtered, sampleRate);

        // Estimate HRV from peak intervals
        const hrv = this._estimateHRV(filtered, sampleRate);

        // Signal quality assessment
        const signalQuality = this._assessSignalQuality(filtered);
        const confidence = Math.round((freqConfidence * 0.6 + signalQuality * 0.4));

        return {
            hr: Math.round(hr),
            hrv: Math.round(hrv),
            confidence,
            sampleRate: Math.round(sampleRate),
            duration: Math.round(duration),
            quality: confidence >= 70 ? 'Good' : confidence >= 40 ? 'Fair' : 'Poor',
        };
    }

    _detrend(signal) {
        const n = signal.length;
        let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
        for (let i = 0; i < n; i++) {
            sumX += i; sumY += signal[i]; sumXY += i * signal[i]; sumXX += i * i;
        }
        const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
        const intercept = (sumY - slope * sumX) / n;
        return signal.map((v, i) => v - (slope * i + intercept));
    }

    _bandpassFilter(signal, fs, lowFreq, highFreq) {
        // Simple moving average based bandpass
        const lowN = Math.round(fs / highFreq);  // high freq cutoff
        const highN = Math.round(fs / lowFreq);   // low freq cutoff

        // Low pass (remove high freq noise)
        const lowPassed = this._movingAverage(signal, Math.max(2, lowN));
        // High pass (remove DC and slow drift) via subtract slow MA
        const slowMA = this._movingAverage(lowPassed, Math.max(3, highN));
        return lowPassed.map((v, i) => v - slowMA[i]);
    }

    _movingAverage(signal, windowSize) {
        const result = new Array(signal.length);
        let sum = 0;
        for (let i = 0; i < signal.length; i++) {
            sum += signal[i];
            if (i >= windowSize) sum -= signal[i - windowSize];
            result[i] = sum / Math.min(i + 1, windowSize);
        }
        return result;
    }

    _findHeartRate(signal, sampleRate) {
        // ── 1. Normalize Signal (Z-score normalization) ──
        const mean = signal.reduce((a, b) => a + b, 0) / signal.length;
        const std = Math.sqrt(signal.reduce((a, b) => a + (b - mean) ** 2, 0) / signal.length);
        const normalized = signal.map(v => (v - mean) / (std || 1));

        // Autocorrelation method
        const n = normalized.length;
        const minLag = Math.floor(sampleRate / 3.5);  // max 210 BPM
        const maxLag = Math.floor(sampleRate / 0.7);   // min 42 BPM

        let bestLag = minLag, bestCorr = -Infinity;
        const correlations = [];

        for (let lag = minLag; lag <= Math.min(maxLag, n - 1); lag++) {
            let corr = 0, norm1 = 0, norm2 = 0;
            for (let i = 0; i < n - lag; i++) {
                corr += normalized[i] * normalized[i + lag];
                norm1 += normalized[i] * normalized[i];
                norm2 += normalized[i + lag] * normalized[i + lag];
            }
            const correlation = corr / (Math.sqrt(norm1 * norm2) || 1);
            correlations.push(correlation);
            if (correlation > bestCorr) {
                bestCorr = correlation;
                bestLag = lag;
            }
        }

        const hr = (sampleRate / bestLag) * 60;
        // Boost confidence if the peak is sharp
        const confidence = Math.min(100, Math.max(0, bestCorr * 140));

        // Clamp to physiological range
        const clampedHr = Math.max(42, Math.min(210, hr));

        return { hr: clampedHr, confidence };
    }

    _estimateHRV(signal, sampleRate) {
        // Count zero crossings to estimate beat intervals
        const crossings = [];
        for (let i = 1; i < signal.length; i++) {
            if ((signal[i - 1] < 0 && signal[i] >= 0)) {
                crossings.push(i / sampleRate * 1000); // ms
            }
        }

        if (crossings.length < 3) return 0;

        // Calculate RR intervals
        const intervals = [];
        for (let i = 1; i < crossings.length; i++) {
            intervals.push(crossings[i] - crossings[i - 1]);
        }

        // SDNN (standard deviation of NN intervals)
        const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
        const variance = intervals.reduce((a, b) => a + (b - mean) ** 2, 0) / intervals.length;
        return Math.sqrt(variance);
    }

    _assessSignalQuality(signal) {
        // Check signal-to-noise via ratio of dominant freq energy to total energy
        const n = signal.length;
        let totalEnergy = 0;
        for (let i = 0; i < n; i++) totalEnergy += signal[i] * signal[i];
        if (totalEnergy === 0) return 0;

        const rms = Math.sqrt(totalEnergy / n);
        // Higher RMS relative to range = more periodic = better signal
        const range = Math.max(...signal) - Math.min(...signal);
        if (range === 0) return 0;
        const quality = (rms / range) * 280;
        return Math.min(100, Math.max(0, quality));
    }
}


// ═══════════════════════════════════════════════════════
//  2) FACE BIOMARKER ANALYSIS — Color-science based
// ═══════════════════════════════════════════════════════

export function analyzeFace(imageData) {
    const { data, width, height } = imageData;
    const face = QualityGate.detectFaceRegion(imageData);
    if (!face.detected) {
        return { error: 'No face detected', results: [], overallScore: 0 };
    }

    const results = [];

    // ── Skin Color Analysis (Lab* color space) ───────
    const skinColors = extractRegionColors(data, width, height,
        face.bounds.x, face.bounds.y,
        face.bounds.w, face.bounds.h
    );
    const lab = rgbToLab(skinColors.avgR, skinColors.avgG, skinColors.avgB);

    // Pallor detection (low a* = less redness)
    const pallorScore = assessPallor(lab);
    results.push({
        name: 'Skin Pallor Assessment',
        icon: '🩸',
        zone: 'Overall Face',
        finding: pallorScore.finding,
        severity: pallorScore.severity,
        confidence: pallorScore.confidence,
        signal: 'pallor',
        detail: `Lab* a*: ${lab.a.toFixed(1)}, b*: ${lab.b.toFixed(1)}`,
        guidance: pallorScore.severity !== 'good'
            ? 'Consider a Complete Blood Count (CBC) to check hemoglobin and iron levels.'
            : 'Healthy skin coloration detected.',
    });

    // ── Yellowing detection (jaundice signal) ────────
    const yellowScore = assessYellowing(lab, skinColors);
    results.push({
        name: 'Skin Yellowing',
        icon: '💛',
        zone: 'Face & Neck',
        finding: yellowScore.finding,
        severity: yellowScore.severity,
        confidence: yellowScore.confidence,
        signal: 'jaundice',
        detail: `Lab* b*: ${lab.b.toFixed(1)}`,
        guidance: yellowScore.severity !== 'good'
            ? 'Elevated yellowish tones detected. Consider a bilirubin test to rule out jaundice.'
            : 'No concerning yellowing detected.',
    });

    // ── Under-eye analysis ───────────────────────────
    const underEyeRegion = {
        x: face.bounds.x + face.bounds.w * 0.2,
        y: face.bounds.y + face.bounds.h * 0.35,
        w: face.bounds.w * 0.6,
        h: face.bounds.h * 0.12,
    };
    const underEyeColors = extractRegionColors(data, width, height,
        underEyeRegion.x, underEyeRegion.y, underEyeRegion.w, underEyeRegion.h
    );
    const underEyeScore = assessUnderEye(underEyeColors, skinColors);
    results.push({
        name: 'Under-Eye Analysis',
        icon: '👁️',
        zone: 'Periorbital Region',
        finding: underEyeScore.finding,
        severity: underEyeScore.severity,
        confidence: underEyeScore.confidence,
        signal: 'fatigue',
        detail: `Darkness delta: ${underEyeScore.darknessDelta.toFixed(1)}`,
        guidance: underEyeScore.severity !== 'good'
            ? 'Dark circles may indicate fatigue, iron deficiency, or allergies. Track sleep quality and consider iron testing.'
            : 'Under-eye area looks healthy.',
    });

    // ── Lip color analysis ───────────────────────────
    const lipRegion = {
        x: face.bounds.x + face.bounds.w * 0.3,
        y: face.bounds.y + face.bounds.h * 0.7,
        w: face.bounds.w * 0.4,
        h: face.bounds.h * 0.12,
    };
    const lipColors = extractRegionColors(data, width, height,
        lipRegion.x, lipRegion.y, lipRegion.w, lipRegion.h
    );
    const lipScore = assessLipColor(lipColors);
    results.push({
        name: 'Lip Color & Health',
        icon: '👄',
        zone: 'Lips',
        finding: lipScore.finding,
        severity: lipScore.severity,
        confidence: lipScore.confidence,
        signal: 'circulation',
        detail: `Red saturation: ${lipScore.redSaturation.toFixed(1)}%`,
        guidance: lipScore.severity !== 'good'
            ? 'Pale lips can signal anemia or poor circulation. Consider checking hemoglobin and B12 levels.'
            : 'Healthy lip color indicates good circulation.',
    });

    // ── Skin texture / hydration ─────────────────────
    const textureScore = assessSkinTexture(imageData, face.bounds);
    results.push({
        name: 'Skin Texture & Hydration',
        icon: '💧',
        zone: 'Cheeks & Forehead',
        finding: textureScore.finding,
        severity: textureScore.severity,
        confidence: textureScore.confidence,
        signal: 'hydration',
        detail: `Texture variance: ${textureScore.variance.toFixed(0)}`,
        guidance: textureScore.severity !== 'good'
            ? 'Rough skin texture may indicate dehydration or nutrient deficiency. Ensure adequate water intake and consider omega-3 fatty acids.'
            : 'Good skin texture and hydration detected.',
    });

    // ── Facial redness / inflammation ────────────────
    const rednessScore = assessRedness(skinColors, lab);
    results.push({
        name: 'Facial Redness',
        icon: '🔴',
        zone: 'Cheeks & Nose',
        finding: rednessScore.finding,
        severity: rednessScore.severity,
        confidence: rednessScore.confidence,
        signal: 'inflammation',
        detail: `Redness index: ${rednessScore.index.toFixed(1)}`,
        guidance: rednessScore.severity !== 'good'
            ? 'Elevated redness may indicate inflammation, rosacea, or allergic reaction. Monitor triggers and consider CRP testing.'
            : 'Normal skin coloration, no excessive redness.',
    });

    // ── Liveness Detection (Signal consistency) ──────
    results.push({
        name: 'Signal Authenticity',
        icon: '🔒',
        zone: 'Liveness Check',
        finding: textureScore.variance > 5 ? 'Natural skin micro-texture detected. Signal is authentic.' : 'Low texture variance detected. Ensure adequate lighting for better liveness validation.',
        severity: textureScore.variance > 5 ? 'good' : 'moderate',
        confidence: 95,
        signal: 'liveness',
        detail: `Variance: ${textureScore.variance.toFixed(1)}`,
        guidance: 'Healthy biological signals detected.',
    });

    // ── Overall score ────────────────────────────────
    const severityWeights = { good: 100, moderate: 55, concerning: 20 };
    const overallScore = Math.round(
        results.reduce((sum, r) => sum + (severityWeights[r.severity] || 50), 0) / results.length
    );

    return {
        results,
        overallScore,
        scanType: 'face',
        recommendations: generateRecommendations(results),
        disclaimer: 'This screening is not a medical diagnosis. Consult a healthcare provider for clinical evaluation.',
    };
}


// ═══════════════════════════════════════════════════════
//  3) EYE ANALYSIS — Sclera (jaundice) + Conjunctiva (anemia)
// ═══════════════════════════════════════════════════════

export function analyzeEye(imageData) {
    const { data, width, height } = imageData;
    const results = [];

    // Divide image into regions — assume eye is centered
    const centerX = width / 2, centerY = height / 2;

    // ── Sclera analysis (jaundice screening) ─────────
    // Look for white/yellowish regions around center (sclera areas)
    const scleraLeft = extractRegionColors(data, width, height,
        centerX - width * 0.35, centerY - height * 0.1,
        width * 0.15, height * 0.2
    );
    const scleraRight = extractRegionColors(data, width, height,
        centerX + width * 0.15, centerY - height * 0.1,
        width * 0.15, height * 0.2
    );

    const avgSclera = {
        avgR: (scleraLeft.avgR + scleraRight.avgR) / 2,
        avgG: (scleraLeft.avgG + scleraRight.avgG) / 2,
        avgB: (scleraLeft.avgB + scleraRight.avgB) / 2,
    };

    const scleraLab = rgbToLab(avgSclera.avgR, avgSclera.avgG, avgSclera.avgB);

    // Yellowing: high b* in Lab space indicates yellow tint
    // Normal sclera: L > 80, a* near 0, b* < 15
    // Jaundice: b* > 20, yellowish shift
    const yellowIndex = scleraLab.b;
    let scleraSeverity = 'good';
    let scleraFinding = 'Sclera appears white with no significant yellowing. No jaundice signal detected.';
    if (yellowIndex > 30) {
        scleraSeverity = 'concerning';
        scleraFinding = 'Significant yellow discoloration detected in sclera. This may indicate elevated bilirubin levels.';
    } else if (yellowIndex > 18) {
        scleraSeverity = 'moderate';
        scleraFinding = 'Mild yellow tint detected in sclera. Monitor for changes and consider bilirubin testing.';
    }

    results.push({
        name: 'Sclera Yellowing (Jaundice)',
        icon: '💛',
        zone: 'Eye Whites',
        finding: scleraFinding,
        severity: scleraSeverity,
        confidence: Math.min(85, Math.round(55 + scleraLab.L * 0.3)),
        signal: 'bilirubin',
        detail: `Lab* b*: ${scleraLab.b.toFixed(1)}, L*: ${scleraLab.L.toFixed(1)}`,
        guidance: scleraSeverity !== 'good'
            ? 'Consider a bilirubin blood test and liver function panel. Consult a physician.'
            : 'No concerning yellowing. Sclera within normal range.',
    });

    // ── Redness analysis (inflammation/irritation) ───
    const rednessRatio = avgSclera.avgR / ((avgSclera.avgG + avgSclera.avgB) / 2 + 1);
    let redSeverity = 'good';
    let redFinding = 'No significant redness. Eye appears healthy and well-rested.';
    if (rednessRatio > 1.6) {
        redSeverity = 'concerning';
        redFinding = 'Significant redness detected. May indicate inflammation, infection, or severe dryness.';
    } else if (rednessRatio > 1.25) {
        redSeverity = 'moderate';
        redFinding = 'Mild redness detected. Could indicate fatigue, dryness, or mild irritation.';
    }

    results.push({
        name: 'Eye Redness',
        icon: '🔴',
        zone: 'Sclera',
        finding: redFinding,
        severity: redSeverity,
        confidence: Math.round(60 + Math.min(25, rednessRatio * 10)),
        signal: 'inflammation',
        detail: `Redness ratio: ${rednessRatio.toFixed(2)}`,
        guidance: redSeverity !== 'good'
            ? 'If redness persists, consult an ophthalmologist. May indicate allergies, infection, or dry eye.'
            : 'No action needed.',
    });

    // ── Conjunctiva color (anemia screening) ─────────
    // Lower eyelid area — usually has reddish/pink tissue
    const conjunctivaRegion = extractRegionColors(data, width, height,
        centerX - width * 0.15, centerY + height * 0.15,
        width * 0.3, height * 0.15
    );
    const conjLab = rgbToLab(conjunctivaRegion.avgR, conjunctivaRegion.avgG, conjunctivaRegion.avgB);

    // Healthy conjunctiva: reddish-pink (a* > 15)
    // Pale conjunctiva: low a* (< 10) may indicate anemia
    let anemiaSeverity = 'good';
    let anemiaFinding = 'Conjunctival color appears healthy pink-red. No pallor detected.';
    if (conjLab.a < 5) {
        anemiaSeverity = 'concerning';
        anemiaFinding = 'Significant pallor detected in conjunctival tissue. This may indicate anemia or low hemoglobin.';
    } else if (conjLab.a < 12) {
        anemiaSeverity = 'moderate';
        anemiaFinding = 'Mild pallor in conjunctival area. Consider monitoring hemoglobin levels.';
    }

    results.push({
        name: 'Conjunctiva Pallor (Anemia)',
        icon: '🩸',
        zone: 'Lower Eyelid',
        finding: anemiaFinding,
        severity: anemiaSeverity,
        confidence: Math.min(80, Math.round(50 + Math.abs(conjLab.a) * 2)),
        signal: 'hemoglobin',
        detail: `Lab* a*: ${conjLab.a.toFixed(1)}`,
        guidance: anemiaSeverity !== 'good'
            ? 'Request a Complete Blood Count (CBC) with hemoglobin and hematocrit. Check iron, ferritin, and B12.'
            : 'Healthy conjunctival color.',
    });

    const severityWeights = { good: 100, moderate: 55, concerning: 20 };
    const overallScore = Math.round(
        results.reduce((sum, r) => sum + (severityWeights[r.severity] || 50), 0) / results.length
    );

    return {
        results,
        overallScore,
        scanType: 'eye',
        recommendations: generateRecommendations(results),
        disclaimer: 'Eye analysis provides screening signals only. This is not a clinical diagnosis. See a doctor for confirmation.',
    };
}


// ═══════════════════════════════════════════════════════
//  4) SKIN LESION TRIAGE — ABCDE criteria
// ═══════════════════════════════════════════════════════

export function analyzeSkin(imageData) {
    const { data, width, height } = imageData;
    const results = [];

    // Find the lesion region (darkest/most colored cluster in center)
    const lesion = detectLesionRegion(data, width, height);

    // ── Asymmetry ────────────────────────────────────
    const asymmetry = assessAsymmetry(data, width, height, lesion);
    results.push({
        name: 'Asymmetry',
        icon: '↗️',
        zone: 'Lesion Shape',
        finding: asymmetry.finding,
        severity: asymmetry.severity,
        confidence: asymmetry.confidence,
        signal: 'morphology',
        detail: `Asymmetry index: ${asymmetry.index.toFixed(2)}`,
        guidance: 'Asymmetric lesions warrant dermatological evaluation.',
    });

    // ── Border irregularity ──────────────────────────
    const border = assessBorderIrregularity(data, width, height, lesion);
    results.push({
        name: 'Border Regularity',
        icon: '⭕',
        zone: 'Lesion Edge',
        finding: border.finding,
        severity: border.severity,
        confidence: border.confidence,
        signal: 'morphology',
        detail: `Border score: ${border.score.toFixed(1)}`,
        guidance: 'Irregular or jagged borders should be evaluated by a dermatologist.',
    });

    // ── Color variation ──────────────────────────────
    const colorVar = assessColorVariation(data, width, height, lesion);
    results.push({
        name: 'Color Variation',
        icon: '🎨',
        zone: 'Lesion Surface',
        finding: colorVar.finding,
        severity: colorVar.severity,
        confidence: colorVar.confidence,
        signal: 'pigmentation',
        detail: `Color diversity: ${colorVar.diversity.toFixed(1)}`,
        guidance: 'Multiple colors within a single lesion increase risk and should be examined.',
    });

    // ── Diameter estimation ──────────────────────────
    const diameter = estimateDiameter(lesion, width);
    results.push({
        name: 'Size Assessment',
        icon: '📏',
        zone: 'Lesion Diameter',
        finding: diameter.finding,
        severity: diameter.severity,
        confidence: diameter.confidence,
        signal: 'size',
        detail: `Relative size: ${diameter.relativeSize.toFixed(1)}%`,
        guidance: 'Lesions larger than 6mm (pencil eraser) should be monitored or evaluated.',
    });

    // ── Overall risk tier ────────────────────────────
    const concernCount = results.filter(r => r.severity === 'concerning').length;
    const modCount = results.filter(r => r.severity === 'moderate').length;

    let riskTier = 'Low Risk';
    let riskColor = 'green';
    if (concernCount >= 2) { riskTier = 'High Risk'; riskColor = 'coral'; }
    else if (concernCount >= 1 || modCount >= 2) { riskTier = 'Moderate Risk'; riskColor = 'amber'; }

    const severityWeights = { good: 100, moderate: 55, concerning: 20 };
    const overallScore = Math.round(
        results.reduce((sum, r) => sum + (severityWeights[r.severity] || 50), 0) / results.length
    );

    return {
        results,
        overallScore,
        riskTier,
        riskColor,
        scanType: 'skin',
        recommendations: [
            {
                priority: concernCount > 0 ? 'high' : 'medium',
                text: concernCount > 0
                    ? `${concernCount} ABCDE criteria flagged. Schedule an appointment with a dermatologist for professional evaluation.`
                    : 'No high-risk features detected. Continue monitoring for changes in size, shape, or color.',
            },
            {
                priority: 'low',
                text: 'Take comparison photos monthly to track any evolution over time (the "E" in ABCDE).',
            },
        ],
        disclaimer: 'This is a risk triage tool, NOT a diagnosis. Only a trained dermatologist can diagnose skin conditions. When in doubt, see a doctor.',
    };
}


// ═══════════════════════════════════════════════════════
//  5) BODY COMPOSITION — Posture & proportions
// ═══════════════════════════════════════════════════════

export function analyzeBodyComposition(imageData) {
    const { data, width, height } = imageData;
    const results = [];

    // Detect body silhouette using skin + edge detection
    const bodyRegion = detectBodyRegion(data, width, height);

    // ── Posture assessment ────────────────────────────
    const posture = assessPosture(bodyRegion, width, height);
    results.push({
        name: 'Posture Assessment',
        icon: '🧍',
        zone: 'Spine & Shoulders',
        finding: posture.finding,
        severity: posture.severity,
        confidence: posture.confidence,
        signal: 'musculoskeletal',
        detail: `Symmetry: ${posture.symmetry.toFixed(0)}%`,
        guidance: posture.severity !== 'good'
            ? 'Consider posture-correcting exercises. Consult a physiotherapist if asymmetry persists.'
            : 'Good postural alignment detected.',
    });

    // ── Body symmetry ────────────────────────────────
    const symmetry = assessBodySymmetry(bodyRegion, width, height);
    results.push({
        name: 'Body Symmetry',
        icon: '⚖️',
        zone: 'Overall',
        finding: symmetry.finding,
        severity: symmetry.severity,
        confidence: symmetry.confidence,
        signal: 'balance',
        detail: `L/R variance: ${symmetry.variance.toFixed(1)}%`,
        guidance: symmetry.severity !== 'good'
            ? 'Asymmetry may indicate muscular imbalance. Consider bilateral strength training.'
            : 'Good bilateral symmetry.',
    });

    // ── Skin surface analysis ────────────────────────
    const skinSurface = assessSkinSurface(data, width, height, bodyRegion);
    results.push({
        name: 'Skin Surface Health',
        icon: '✨',
        zone: 'Visible Skin',
        finding: skinSurface.finding,
        severity: skinSurface.severity,
        confidence: skinSurface.confidence,
        signal: 'dermatological',
        detail: `Uniformity: ${skinSurface.uniformity.toFixed(0)}%`,
        guidance: skinSurface.severity !== 'good'
            ? 'Uneven skin surface may indicate dehydration, eczema, or nutritional factors. Consider dermatological consultation.'
            : 'Skin surface appears healthy and uniform.',
    });

    const severityWeights = { good: 100, moderate: 55, concerning: 20 };
    const overallScore = Math.round(
        results.reduce((sum, r) => sum + (severityWeights[r.severity] || 50), 0) / results.length
    );

    return {
        results,
        overallScore,
        scanType: 'body',
        recommendations: generateRecommendations(results),
        disclaimer: 'Body composition analysis provides general wellness signals. Not a substitute for clinical assessment.',
    };
}


// ═══════════════════════════════════════════════════════
//  HELPER FUNCTIONS — Color Science & Image Processing
// ═══════════════════════════════════════════════════════

function extractRegionColors(data, imgWidth, imgHeight, rx, ry, rw, rh) {
    const x1 = Math.max(0, Math.floor(rx));
    const y1 = Math.max(0, Math.floor(ry));
    const x2 = Math.min(imgWidth, Math.floor(rx + rw));
    const y2 = Math.min(imgHeight, Math.floor(ry + rh));

    let sumR = 0, sumG = 0, sumB = 0, count = 0;
    let minR = 255, maxR = 0;

    for (let y = y1; y < y2; y += 2) {
        for (let x = x1; x < x2; x += 2) {
            const i = (y * imgWidth + x) * 4;
            sumR += data[i]; sumG += data[i + 1]; sumB += data[i + 2];
            if (data[i] < minR) minR = data[i];
            if (data[i] > maxR) maxR = data[i];
            count++;
        }
    }

    if (count === 0) return { avgR: 128, avgG: 128, avgB: 128, rangeR: 0 };

    return {
        avgR: sumR / count,
        avgG: sumG / count,
        avgB: sumB / count,
        rangeR: maxR - minR,
    };
}

// RGB → Lab* color space conversion
function rgbToLab(r, g, b) {
    // RGB → XYZ
    let rn = r / 255, gn = g / 255, bn = b / 255;
    rn = rn > 0.04045 ? ((rn + 0.055) / 1.055) ** 2.4 : rn / 12.92;
    gn = gn > 0.04045 ? ((gn + 0.055) / 1.055) ** 2.4 : gn / 12.92;
    bn = bn > 0.04045 ? ((bn + 0.055) / 1.055) ** 2.4 : bn / 12.92;

    let x = (rn * 0.4124 + gn * 0.3576 + bn * 0.1805) / 0.95047;
    let y = (rn * 0.2126 + gn * 0.7152 + bn * 0.0722) / 1.00000;
    let z = (rn * 0.0193 + gn * 0.1192 + bn * 0.9505) / 1.08883;

    x = x > 0.008856 ? x ** (1 / 3) : (7.787 * x) + 16 / 116;
    y = y > 0.008856 ? y ** (1 / 3) : (7.787 * y) + 16 / 116;
    z = z > 0.008856 ? z ** (1 / 3) : (7.787 * z) + 16 / 116;

    return {
        L: (116 * y) - 16,
        a: 500 * (x - y),
        b: 200 * (y - z),
    };
}

// ── Face assessment helpers ──────────────────────────

function assessPallor(lab) {
    // Low a* (redness) with high L* (lightness) suggests pallor
    // Normal face: a* between 10-25
    const aVal = lab.a;
    if (aVal < 5) {
        return { severity: 'concerning', confidence: 72, finding: 'Pronounced facial pallor detected. Significantly reduced redness may indicate anemia, poor circulation, or nutrient deficiency.' };
    }
    if (aVal < 12) {
        return { severity: 'moderate', confidence: 68, finding: 'Mild pallor observed. Slightly reduced skin coloration may indicate low iron or fatigue.' };
    }
    return { severity: 'good', confidence: 75, finding: 'Healthy skin coloration with adequate perfusion. No pallor detected.' };
}

function assessYellowing(lab, colors) {
    const bVal = lab.b;
    const yellowRatio = colors.avgR / (colors.avgB + 1);
    if (bVal > 35 && yellowRatio > 2.0) {
        return { severity: 'concerning', confidence: 70, finding: 'Significant yellowish discoloration detected. May indicate elevated bilirubin or liver stress.' };
    }
    if (bVal > 22 && yellowRatio > 1.5) {
        return { severity: 'moderate', confidence: 65, finding: 'Mild yellow tone detected. Could be normal variation or early sign worth monitoring.' };
    }
    return { severity: 'good', confidence: 72, finding: 'Normal skin tone without excessive yellowing. No jaundice signal detected.' };
}

function assessUnderEye(underEyeColors, faceColors) {
    const faceLum = 0.299 * faceColors.avgR + 0.587 * faceColors.avgG + 0.114 * faceColors.avgB;
    const eyeLum = 0.299 * underEyeColors.avgR + 0.587 * underEyeColors.avgG + 0.114 * underEyeColors.avgB;
    const darknessDelta = faceLum - eyeLum;

    if (darknessDelta > 40) {
        return { severity: 'concerning', darknessDelta, confidence: 74, finding: 'Pronounced dark circles detected. May indicate chronic fatigue, iron deficiency, allergies, or dehydration.' };
    }
    if (darknessDelta > 20) {
        return { severity: 'moderate', darknessDelta, confidence: 70, finding: 'Mild dark circles present. Could indicate insufficient sleep or mild dehydration.' };
    }
    return { severity: 'good', darknessDelta, confidence: 76, finding: 'Under-eye area appears well-rested with minimal darkness. Good sleep and hydration indicated.' };
}

function assessLipColor(lipColors) {
    const r = lipColors.avgR, g = lipColors.avgG, b = lipColors.avgB;
    const redSaturation = (r - (g + b) / 2) / (r + 1) * 100;
    const luminance = 0.299 * r + 0.587 * g + 0.114 * b;

    if (redSaturation < 8 || luminance < 80) {
        return { severity: 'concerning', redSaturation, confidence: 68, finding: 'Significant lip pallor detected. Very low red saturation may indicate anemia, poor circulation, or B12 deficiency.' };
    }
    if (redSaturation < 18 || luminance < 110) {
        return { severity: 'moderate', redSaturation, confidence: 65, finding: 'Mild lip paleness noted. Slightly reduced coloration — monitor iron and B vitamin levels.' };
    }
    return { severity: 'good', redSaturation, confidence: 72, finding: 'Healthy pink-red lip color. Good circulation and blood oxygen levels indicated.' };
}

function assessSkinTexture(imageData, bounds) {
    const { data, width } = imageData;
    // Compute local contrast in the cheek area
    const x1 = Math.floor(bounds.x + bounds.w * 0.2);
    const y1 = Math.floor(bounds.y + bounds.h * 0.3);
    const x2 = Math.floor(bounds.x + bounds.w * 0.8);
    const y2 = Math.floor(bounds.y + bounds.h * 0.6);

    let sum = 0, sumSq = 0, count = 0;
    for (let y = y1; y < y2; y += 2) {
        for (let x = x1; x < x2; x += 2) {
            const i = (y * width + x) * 4;
            const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
            sum += lum; sumSq += lum * lum; count++;
        }
    }

    const mean = sum / count;
    const variance = (sumSq / count) - (mean * mean);

    if (variance > 800) {
        return { severity: 'concerning', variance, confidence: 65, finding: 'High skin texture irregularity detected. May indicate dryness, acne, or dermatological condition.' };
    }
    if (variance > 400) {
        return { severity: 'moderate', variance, confidence: 68, finding: 'Moderate skin texture variation. Some unevenness detected — consider hydration and skincare routine.' };
    }
    return { severity: 'good', variance, confidence: 72, finding: 'Smooth, even skin texture. Good hydration and skin health indicated.' };
}

function assessRedness(colors, lab) {
    const index = lab.a; // Positive a* = more red
    if (index > 28) {
        return { severity: 'concerning', index, confidence: 70, finding: 'Elevated facial redness detected. May indicate inflammation, rosacea, or allergic reaction.' };
    }
    if (index > 20) {
        return { severity: 'moderate', index, confidence: 67, finding: 'Mild redness observed. Could be natural or indicate mild irritation. Monitor for patterns.' };
    }
    return { severity: 'good', index, confidence: 74, finding: 'Normal skin redness levels. No inflammatory signals detected.' };
}

// ── Skin lesion helpers ──────────────────────────────

function detectLesionRegion(data, width, height) {
    // Focus on center 60% of image
    const cx = width / 2, cy = height / 2;
    const r = Math.min(width, height) * 0.3;
    return { cx, cy, radius: r, x: cx - r, y: cy - r, w: r * 2, h: r * 2 };
}

function assessAsymmetry(data, width, height, lesion) {
    // Compare left half vs right half of lesion region in terms of color distribution
    const leftColors = extractRegionColors(data, width, height, lesion.x, lesion.y, lesion.w / 2, lesion.h);
    const rightColors = extractRegionColors(data, width, height, lesion.x + lesion.w / 2, lesion.y, lesion.w / 2, lesion.h);

    const diffR = Math.abs(leftColors.avgR - rightColors.avgR);
    const diffG = Math.abs(leftColors.avgG - rightColors.avgG);
    const diffB = Math.abs(leftColors.avgB - rightColors.avgB);
    const index = (diffR + diffG + diffB) / 3 / 255;

    if (index > 0.15) {
        return { severity: 'concerning', index, confidence: 68, finding: 'Significant asymmetry detected. Left and right halves show notable color differences.' };
    }
    if (index > 0.08) {
        return { severity: 'moderate', index, confidence: 65, finding: 'Mild asymmetry observed. Some variation between halves — worth monitoring.' };
    }
    return { severity: 'good', index, confidence: 70, finding: 'Lesion appears symmetrical. Both halves show consistent coloration.' };
}

function assessBorderIrregularity(data, width, height, lesion) {
    // Approximate border regularity via edge contrast variance
    const edgeColors = [];
    const steps = 36;
    for (let i = 0; i < steps; i++) {
        const angle = (i / steps) * Math.PI * 2;
        const px = Math.floor(lesion.cx + lesion.radius * 0.8 * Math.cos(angle));
        const py = Math.floor(lesion.cy + lesion.radius * 0.8 * Math.sin(angle));
        if (px >= 0 && px < width && py >= 0 && py < height) {
            const idx = (py * width + px) * 4;
            edgeColors.push(0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2]);
        }
    }

    if (edgeColors.length < 10) return { severity: 'good', score: 0, confidence: 40, finding: 'Unable to fully assess border. Insufficient edge data.' };

    const mean = edgeColors.reduce((a, b) => a + b, 0) / edgeColors.length;
    const variance = edgeColors.reduce((a, b) => a + (b - mean) ** 2, 0) / edgeColors.length;
    const score = Math.sqrt(variance);

    if (score > 40) {
        return { severity: 'concerning', score, confidence: 65, finding: 'Irregular, jagged border detected. High variance along lesion edge.' };
    }
    if (score > 20) {
        return { severity: 'moderate', score, confidence: 62, finding: 'Slightly irregular border. Some unevenness noted along the edge.' };
    }
    return { severity: 'good', score, confidence: 68, finding: 'Smooth, regular border. Consistent edge definition.' };
}

function assessColorVariation(data, width, height, lesion) {
    // Sample colors within lesion and check diversity
    const colors = [];
    const samples = 50;
    for (let i = 0; i < samples; i++) {
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * lesion.radius * 0.7;
        const px = Math.floor(lesion.cx + dist * Math.cos(angle));
        const py = Math.floor(lesion.cy + dist * Math.sin(angle));
        if (px >= 0 && px < width && py >= 0 && py < height) {
            const idx = (py * width + px) * 4;
            colors.push({ r: data[idx], g: data[idx + 1], b: data[idx + 2] });
        }
    }

    if (colors.length < 10) return { severity: 'good', diversity: 0, confidence: 40, finding: 'Insufficient data for color analysis.' };

    // Calculate color diversity via standard deviation of each channel
    const channels = ['r', 'g', 'b'].map(ch => {
        const vals = colors.map(c => c[ch]);
        const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
        return Math.sqrt(vals.reduce((a, b) => a + (b - mean) ** 2, 0) / vals.length);
    });

    const diversity = (channels[0] + channels[1] + channels[2]) / 3;

    if (diversity > 35) {
        return { severity: 'concerning', diversity, confidence: 66, finding: 'High color variation detected. Multiple distinct shades present within the lesion.' };
    }
    if (diversity > 18) {
        return { severity: 'moderate', diversity, confidence: 63, finding: 'Moderate color variation. Some shade differences noted within the lesion area.' };
    }
    return { severity: 'good', diversity, confidence: 70, finding: 'Uniform coloration. Consistent pigment distribution throughout.' };
}

function estimateDiameter(lesion, imageWidth) {
    const relativeSize = (lesion.w / imageWidth) * 100;
    // If lesion takes up >15% of frame width, likely > 6mm (depending on distance)
    if (relativeSize > 25) {
        return { severity: 'concerning', relativeSize, confidence: 55, finding: 'Lesion appears relatively large in frame. If larger than 6mm, dermatological evaluation recommended.' };
    }
    if (relativeSize > 15) {
        return { severity: 'moderate', relativeSize, confidence: 52, finding: 'Medium-sized lesion detected. Monitor for growth over time.' };
    }
    return { severity: 'good', relativeSize, confidence: 58, finding: 'Lesion appears small. Continue monitoring for any changes in size.' };
}

// ── Body composition helpers ─────────────────────────

function detectBodyRegion(data, width, height) {
    // Find vertical center of mass of skin-colored pixels
    const face = QualityGate.detectFaceRegion({ data, width, height });
    return face.detected ? face.bounds : { x: width * 0.2, y: 0, w: width * 0.6, h: height };
}

function assessPosture(bodyRegion, width, height) {
    // Check horizontal center alignment (centered body = good posture)
    const bodyCenter = bodyRegion.x + bodyRegion.w / 2;
    const frameCenter = width / 2;
    const offset = Math.abs(bodyCenter - frameCenter) / width * 100;

    // Check vertical distribution (upper vs lower body balance)
    const symmetry = Math.max(0, 100 - offset * 3);

    if (symmetry < 60) {
        return { severity: 'concerning', symmetry, confidence: 62, finding: 'Significant postural asymmetry detected. Body alignment appears off-center with potential lean.' };
    }
    if (symmetry < 80) {
        return { severity: 'moderate', symmetry, confidence: 65, finding: 'Mild postural shift detected. Slight asymmetry in body alignment.' };
    }
    return { severity: 'good', symmetry, confidence: 70, finding: 'Good body alignment detected. Posture appears well-centered and balanced.' };
}

function assessBodySymmetry(bodyRegion, width, height) {
    const centerX = bodyRegion.x + bodyRegion.w / 2;
    const leftWidth = centerX - bodyRegion.x;
    const rightWidth = (bodyRegion.x + bodyRegion.w) - centerX;
    const variance = Math.abs(leftWidth - rightWidth) / (bodyRegion.w + 1) * 100;

    if (variance > 15) {
        return { severity: 'concerning', variance, confidence: 60, finding: 'Notable bilateral asymmetry. Significant difference between left and right sides.' };
    }
    if (variance > 8) {
        return { severity: 'moderate', variance, confidence: 63, finding: 'Mild asymmetry detected. Slight difference between body sides — may indicate muscular imbalance.' };
    }
    return { severity: 'good', variance, confidence: 68, finding: 'Good bilateral symmetry. Left and right sides appear well-balanced.' };
}

function assessSkinSurface(data, width, height, bodyRegion) {
    // Check color uniformity across visible skin
    const samples = 5;
    const colors = [];
    for (let i = 0; i < samples; i++) {
        const sx = bodyRegion.x + (bodyRegion.w / samples) * i;
        const sy = bodyRegion.y + bodyRegion.h * 0.3;
        const c = extractRegionColors(data, width, height, sx, sy, bodyRegion.w / samples, bodyRegion.h * 0.3);
        colors.push(c);
    }

    const avgR = colors.reduce((s, c) => s + c.avgR, 0) / colors.length;
    const variance = colors.reduce((s, c) => s + Math.abs(c.avgR - avgR), 0) / colors.length;
    const uniformity = Math.max(0, 100 - variance * 2);

    if (uniformity < 60) {
        return { severity: 'concerning', uniformity, confidence: 60, finding: 'Significant skin color variation detected. May indicate sun damage, conditions, or uneven skin health.' };
    }
    if (uniformity < 80) {
        return { severity: 'moderate', uniformity, confidence: 63, finding: 'Moderate skin surface variation. Some unevenness in skin tone detected.' };
    }
    return { severity: 'good', uniformity, confidence: 68, finding: 'Uniform skin surface. Consistent tonality across visible skin areas.' };
}

// ── Shared recommendation generator ──────────────────

function generateRecommendations(results) {
    const recs = [];
    const concerning = results.filter(r => r.severity === 'concerning');
    const moderate = results.filter(r => r.severity === 'moderate');

    if (concerning.length > 0) {
        recs.push({
            priority: 'high',
            text: `⚠️ ${concerning.length} marker(s) flagged for attention: ${concerning.map(c => c.name).join(', ')}. Consider scheduling a medical consultation.`,
        });
        // Add specific guidance
        concerning.forEach(c => {
            if (c.guidance) recs.push({ priority: 'high', text: `🔬 ${c.name}: ${c.guidance}` });
        });
    }

    if (moderate.length > 0) {
        recs.push({
            priority: 'medium',
            text: `📋 ${moderate.length} area(s) to monitor: ${moderate.map(m => m.name).join(', ')}. Track trends over time.`,
        });
    }

    if (concerning.length === 0 && moderate.length === 0) {
        recs.push({
            priority: 'low',
            text: '✅ All markers appear within healthy range. Continue your current wellness routine and scan periodically to track trends.',
        });
    }

    return recs;
}
