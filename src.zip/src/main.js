import { Router } from './router.js';
import { store } from './store.js';
import { icons } from './icons.js';
import { renderDashboard } from './pages/dashboard.js';
import { renderFoodScanner } from './pages/food-scanner.js';
import { renderBodyScanner } from './pages/body-scanner.js';
import { renderStoolScanner } from './pages/stool-scanner.js';
import { renderHealthInput } from './pages/health-input.js';
import { renderEasternMedicine } from './pages/eastern-medicine.js';
import { renderAnalytics } from './pages/analytics.js';
import { renderProfile } from './pages/profile.js';
import { renderHealthChat } from './pages/health-chat.js';
import { renderStepDetails } from './pages/step-details.js';
import { renderProductResults } from './pages/product-results.js';
import { checkOAuthCallback, exchangeCodeForToken } from './utils/strava.js';
import { getSession, renderAuth, signOut } from './pages/auth.js'; // ← new

// Initialize navigation
function initNav() {
  const nav = document.getElementById('bottom-nav');
  const items = [
    { route: '/', icon: icons.home, label: 'Home' },
    { route: '/food-scanner', icon: icons.scan, label: 'Food' },
    { route: '/body-scanner', icon: icons.eye, label: 'Scan' },
    { route: '/health-input', icon: icons.clipboard, label: 'Log' },
    { route: '/health-chat', icon: icons.sparkle, label: 'AI Chat' },
  ];

  nav.innerHTML = items.map(item => `
    <div class="nav-item${item.route === '/' ? ' active' : ''}" data-route="${item.route}">
      ${item.icon}
      <span>${item.label}</span>
    </div>
  `).join('');

  nav.querySelectorAll('.nav-item').forEach(navItem => {
    navItem.addEventListener('click', () => {
      location.hash = '#' + navItem.dataset.route;
    });
  });
}

// Onboarding
function showOnboarding() {
  const slides = [
    { emoji: '🔬', title: 'Welcome to VitalLens', desc: 'Your AI-powered health intelligence platform' },
    { emoji: '🍎', title: 'Scan Your Food', desc: 'Get instant nutrition analysis and food pairing insights' },
    { emoji: '👤', title: 'Detect Biomarkers', desc: 'Face & body scanning reveals hidden health indicators' },
    { emoji: '🧘', title: 'Eastern Wisdom', desc: 'Ayurveda, Chinese medicine & holistic wellness guidance' },
    { emoji: '📊', title: 'Track Everything', desc: 'Build your personalized health database over time' },
  ];

  let current = 0;

  const overlay = document.createElement('div');
  overlay.className = 'onboarding-overlay';
  overlay.id = 'onboarding';

  document.body.appendChild(overlay);

  function renderSlide() {
    overlay.innerHTML = `
      <div class="onboarding-slide animate-fade-in-up">
        <div class="onboarding-icon">${slides[current].emoji}</div>
        <h2 style="font-size:var(--text-2xl);">${slides[current].title}</h2>
        <p style="font-size:var(--text-base);color:var(--text-secondary);max-width:280px;">${slides[current].desc}</p>
        <div class="onboarding-dots">
          ${slides.map((_, i) => `<div class="onboarding-dot ${i === current ? 'active' : ''}"></div>`).join('')}
        </div>
        <button class="btn btn-primary btn-lg" id="onboarding-next">
          ${current === slides.length - 1 ? 'Get Started' : 'Next'}
        </button>
        ${current > 0 ? '<button class="btn btn-ghost" id="onboarding-skip">Skip</button>' : ''}
      </div>
    `;

    const nextBtn = overlay.querySelector('#onboarding-next');
    const skipBtn = overlay.querySelector('#onboarding-skip');

    if (nextBtn) {
      nextBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (current < slides.length - 1) {
          current++;
          renderSlide();
        } else {
          finishOnboarding();
        }
      });
    }

    if (skipBtn) {
      skipBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        finishOnboarding();
      });
    }
  }

  function finishOnboarding() {
    store.set('onboardingComplete', true);
    overlay.style.opacity = '0';
    overlay.style.transition = 'opacity 0.3s ease';
    setTimeout(() => overlay.remove(), 300);
  }

  renderSlide();
}

// Initialize app
async function init() {
  // ── Auth check — show login screen if no session ───────────
  const session = await getSession();
  if (!session) {
    renderAuth();
    return; // Stop here — router won't initialize until user logs in
  }
  // ──────────────────────────────────────────────────────────

  initNav();

  const router = new Router({
    '/': renderDashboard,
    '/food-scanner': renderFoodScanner,
    '/body-scanner': renderBodyScanner,
    '/stool-scanner': renderStoolScanner,
    '/health-input': renderHealthInput,
    '/eastern-medicine': renderEasternMedicine,
    '/analytics': renderAnalytics,
    '/profile': renderProfile,
    '/health-chat': renderHealthChat,
    '/step-details': renderStepDetails,
    '/product-results': renderProductResults,
  });

  // Handle Strava OAuth callback
  const stravaCode = checkOAuthCallback();
  if (stravaCode) {
    try {
      await exchangeCodeForToken(stravaCode);
      location.hash = '#/health-input';
      setTimeout(() => {
        const c = document.getElementById('toast-container');
        if (c) {
          const t = document.createElement('div'); t.className = 'toast';
          t.innerHTML = '<span>✅ Strava connected! Sync your activities.</span>';
          c.appendChild(t);
          setTimeout(() => { t.classList.add('removing'); setTimeout(() => t.remove(), 300); }, 3000);
        }
      }, 500);
    } catch (err) {
      console.error('Strava auth failed:', err);
      const c = document.getElementById('toast-container');
      if (c) {
        const t = document.createElement('div'); t.className = 'toast';
        t.innerHTML = `<span>❌ Strava auth failed: ${err.message}</span>`;
        c.appendChild(t);
        setTimeout(() => { t.classList.add('removing'); setTimeout(() => t.remove(), 300); }, 4000);
      }
    }
  }

  // Show onboarding for first-time users
  if (!store.get('onboardingComplete')) {
    showOnboarding();
  }

  // Initial route
  router.resolve();
}

// Start when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}