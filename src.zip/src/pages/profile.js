import { store } from '../store.js';
import { icons } from '../icons.js';
import { computeHealthScore } from '../utils/health-score.js';
import { isOuraConnected, connectOura, disconnectOura } from '../utils/oura.js';

export function renderProfile() {
  const content = document.getElementById('page-content');
  const data = store.getAll();
  const p = data.profile || {};
  const health = computeHealthScore(data);

  content.innerHTML = `
    <div class="profile stagger-children">
      <div class="page-header"><h1>👤 Profile</h1></div>

      <!-- Avatar & Info -->
      <div class="card" style="text-align:center;margin-bottom:var(--space-5);">
        <div style="width:80px;height:80px;border-radius:50%;background:var(--gradient-primary);display:flex;align-items:center;justify-content:center;font-size:36px;margin:0 auto var(--space-3);box-shadow:var(--shadow-glow-teal);">${p.avatar || '🧬'}</div>
        <h3>${p.name || 'Health Explorer'}</h3>
        <p style="font-size:var(--text-sm);">Health Score: <strong style="color:var(--accent-teal);">${health.overall}</strong> • Grade: <strong>${health.grade}</strong></p>
      </div>

      <!-- Personal Info -->
      <div class="card" style="margin-bottom:var(--space-4);">
        <h4 style="margin-bottom:var(--space-4);">Personal Information</h4>
        <form id="profile-form" style="display:flex;flex-direction:column;gap:var(--space-3);">
          <div class="input-group"><label>Name</label><input class="input-field" type="text" id="p-name" value="${p.name || ''}" placeholder="Your name"></div>
          <div class="grid-2">
            <div class="input-group"><label>Age</label><input class="input-field" type="number" id="p-age" value="${p.age || ''}" placeholder="25"></div>
            <div class="input-group"><label>Gender</label>
              <select class="input-field" id="p-gender"><option value="">Select...</option><option ${p.gender === 'male' ? 'selected' : ''}>male</option><option ${p.gender === 'female' ? 'selected' : ''}>female</option><option ${p.gender === 'other' ? 'selected' : ''}>other</option></select>
            </div>
          </div>
          <div class="grid-2">
            <div class="input-group"><label>Height (cm)</label><input class="input-field" type="number" id="p-height" value="${p.height || ''}" placeholder="175"></div>
            <div class="input-group"><label>Weight (kg)</label><input class="input-field" type="number" id="p-weight" value="${p.weight || ''}" placeholder="70"></div>
          </div>
          <button type="submit" class="btn btn-primary btn-block">Save Profile</button>
        </form>
      </div>

      <!-- Avatar Selection -->
      <div class="card" style="margin-bottom:var(--space-4);">
        <h4 style="margin-bottom:var(--space-3);">Avatar</h4>
        <div style="display:flex;flex-wrap:wrap;gap:var(--space-2);justify-content:center;" id="avatar-picker">
          ${['🧬', '🧠', '💪', '🧘', '🌿', '🦋', '🔬', '⚡', '🌟', '🎯', '🦊', '🐉'].map(a =>
    `<div class="avatar-opt" data-avatar="${a}" style="width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;cursor:pointer;background:${p.avatar === a ? 'var(--accent-teal-dim)' : 'var(--bg-glass-heavy)'};border:2px solid ${p.avatar === a ? 'var(--accent-teal)' : 'transparent'};transition:all var(--transition-base);">${a}</div>`
  ).join('')}
        </div>
      </div>

      <!-- Stats -->
      <div class="card" style="margin-bottom:var(--space-4);">
        <h4 style="margin-bottom:var(--space-3);">Your Stats</h4>
        <div style="display:flex;flex-direction:column;gap:var(--space-3);">
          ${renderStatRow('📊 Data Points', Object.values(data).filter(v => Array.isArray(v)).reduce((a, b) => a + b.length, 0))}
          ${renderStatRow('🍽️ Meals Tracked', (data.meals || []).length)}
          ${renderStatRow('🔬 Body Scans', (data.bodyScans || []).length)}
          ${renderStatRow('🧪 Lab Results', (data.labResults || []).length)}
          ${renderStatRow('🏃 Workouts', (data.exerciseLog || []).length)}
          ${renderStatRow('😴 Sleep Entries', (data.sleepLog || []).length)}
          ${renderStatRow('🔥 Logging Streak', (data.streaks?.logging || 0) + ' days')}
          ${renderStatRow('💍 Oura Connected', isOuraConnected() ? 'Yes' : 'No')}
        </div>
      </div>

      <!-- Integrations -->
      <div class="card" style="margin-bottom:var(--space-4);">
        <h4 style="margin-bottom:var(--space-4);">Integrations</h4>
        <div style="display:flex;flex-direction:column;gap:var(--space-3);">
          <div class="activity-item" style="padding:0;border:none;">
            <div class="activity-icon" style="background:#20243e;color:#fff;">${icons.ring}</div>
            <div class="activity-text">
              <div class="title">Oura Ring</div>
              <div class="time">${isOuraConnected() ? 'Connected' : 'Sync sleep & readiness'}</div>
            </div>
            <button class="btn btn-sm ${isOuraConnected() ? 'btn-outline' : 'btn-primary'}" id="toggle-oura">
              ${isOuraConnected() ? 'Disconnect' : 'Connect'}
            </button>
          </div>
        </div>
      </div>

      <!-- Actions -->
      <div style="display:flex;flex-direction:column;gap:var(--space-3);margin-bottom:var(--space-8);">
        <button class="btn btn-secondary btn-block" id="export-data">📥 Export Health Data</button>
        <button class="btn btn-ghost btn-block" id="reset-data" style="color:var(--accent-coral);">🗑️ Reset All Data</button>
      </div>
    </div>`;

  // Form submit
  document.getElementById('profile-form')?.addEventListener('submit', e => {
    e.preventDefault();
    store.set('profile', {
      ...p,
      name: document.getElementById('p-name')?.value || '',
      age: document.getElementById('p-age')?.value || '',
      gender: document.getElementById('p-gender')?.value || '',
      height: document.getElementById('p-height')?.value || '',
      weight: document.getElementById('p-weight')?.value || '',
    });
    showToast('✅ Profile saved');
  });

  // Avatar picker
  document.querySelectorAll('.avatar-opt').forEach(opt => {
    opt.addEventListener('click', () => {
      const avatar = opt.dataset.avatar;
      store.set('profile', { ...store.get('profile'), avatar });
      renderProfile();
      showToast('Avatar updated!');
    });
  });

  // Export
  document.getElementById('export-data')?.addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'vitallens-export.json'; a.click();
    URL.revokeObjectURL(url);
    showToast('📥 Data exported!');
  });

  // Reset
  document.getElementById('reset-data')?.addEventListener('click', () => {
    if (confirm('Are you sure? This will delete all your health data.')) {
      store.reset(); renderProfile(); showToast('Data reset');
    }
  });

  // Oura toggle
  document.getElementById('toggle-oura')?.addEventListener('click', () => {
    if (isOuraConnected()) {
      disconnectOura();
      showToast('💍 Oura disconnected');
    } else {
      connectOura();
      showToast('Connecting to Oura...');
    }
    renderProfile();
  });
}

function renderStatRow(label, value) {
  return `<div style="display:flex;justify-content:space-between;align-items:center;padding:var(--space-2) 0;border-bottom:1px solid var(--border-subtle);">
    <span style="font-size:var(--text-sm);">${label}</span>
    <span style="font-family:var(--font-heading);font-weight:var(--weight-bold);color:var(--accent-teal);">${value}</span>
  </div>`;
}

function showToast(msg) {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div'); t.className = 'toast'; t.innerHTML = `<span>${msg}</span>`;
  c.appendChild(t); setTimeout(() => { t.classList.add('removing'); setTimeout(() => t.remove(), 300); }, 3000);
}
