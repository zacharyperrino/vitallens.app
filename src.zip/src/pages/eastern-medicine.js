import { store } from '../store.js';
import { doshaData, doshaQuiz, faceMappingZones, tongueDiagnosis } from '../utils/eastern-medicine-data.js';

let activeTab = 'dosha';
let quizStep = 0;
let quizAnswers = [];

export function renderEasternMedicine() {
    const content = document.getElementById('page-content');
    content.innerHTML = `
    <div class="eastern-med stagger-children">
      <div class="page-header"><h1>🧘 Eastern Medicine</h1><p>Ayurveda, Chinese medicine & holistic wellness</p></div>
      <div class="tab-bar" id="em-tabs">
        <div class="tab-item active" data-tab="dosha">Dosha Quiz</div>
        <div class="tab-item" data-tab="facemap">Face Map</div>
        <div class="tab-item" data-tab="tongue">Tongue</div>
      </div>
      <div id="em-content"></div>
    </div>`;
    document.querySelectorAll('#em-tabs .tab-item').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('#em-tabs .tab-item').forEach(t => t.classList.remove('active'));
            tab.classList.add('active'); activeTab = tab.dataset.tab; renderEMContent();
        });
    });
    renderEMContent();
}

function renderEMContent() {
    const c = document.getElementById('em-content');
    if (activeTab === 'dosha') c.innerHTML = renderDoshaTab();
    else if (activeTab === 'facemap') c.innerHTML = renderFaceMap();
    else c.innerHTML = renderTongue();
    setupEMHandlers();
}

function renderDoshaTab() {
    const savedDosha = store.get('dosha');
    if (savedDosha && quizStep === 0) return renderDoshaProfile(savedDosha);
    return renderQuiz();
}

function renderQuiz() {
    if (quizStep >= doshaQuiz.length) return finishQuiz();
    const q = doshaQuiz[quizStep];
    return `<div class="animate-fade-in-up" style="display:flex;flex-direction:column;gap:var(--space-4);">
    <div class="card" style="text-align:center;">
      <div style="font-size:var(--text-xs);color:var(--text-tertiary);margin-bottom:var(--space-2);">Question ${quizStep + 1} of ${doshaQuiz.length}</div>
      <div class="progress-bar" style="margin-bottom:var(--space-4);"><div class="progress-fill" style="width:${((quizStep + 1) / doshaQuiz.length) * 100}%"></div></div>
      <h3 style="font-size:var(--text-md);line-height:1.4;">${q.question}</h3>
    </div>
    ${q.options.map((opt, i) => `
      <div class="card card-sm quiz-option" data-dosha="${opt.dosha}" data-idx="${i}" style="cursor:pointer;">
        <p style="font-size:var(--text-sm);color:var(--text-primary);margin:0;">${opt.text}</p>
      </div>
    `).join('')}
  </div>`;
}

function finishQuiz() {
    const counts = { vata: 0, pitta: 0, kapha: 0 };
    quizAnswers.forEach(a => counts[a]++);
    const dominant = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
    store.set('dosha', dominant);
    quizStep = 0; quizAnswers = [];
    return renderDoshaProfile(dominant);
}

function renderDoshaProfile(doshaKey) {
    const d = doshaData[doshaKey];
    return `<div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">
    <div class="card" style="text-align:center;border:1px solid ${d.color}33;">
      <div style="font-size:48px;margin-bottom:var(--space-2);">${d.icon}</div>
      <h2 style="margin-bottom:var(--space-1);">You are <span style="color:${d.color};">${d.name}</span></h2>
      <p style="font-size:var(--text-sm);">${d.element}</p>
      <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:var(--space-2);margin-top:var(--space-3);">
        ${d.qualities.map(q => `<span class="badge" style="background:${d.colorDim};color:${d.color};">${q}</span>`).join('')}
      </div>
    </div>
    <div class="card"><h4 style="margin-bottom:var(--space-2);">🧬 Body Type</h4><p style="font-size:var(--text-sm);">${d.bodyType}</p></div>
    <div class="card"><h4 style="margin-bottom:var(--space-2);">🧠 Personality</h4><p style="font-size:var(--text-sm);">${d.personality}</p></div>
    <div class="card"><h4 style="margin-bottom:var(--space-2);">⚠️ Imbalance Signs</h4>
      <div style="display:flex;flex-wrap:wrap;gap:var(--space-2);">${d.imbalanceSigns.map(s => `<span class="badge badge-amber">${s}</span>`).join('')}</div>
    </div>
    <div class="grid-2">
      <div class="card"><h4 style="margin-bottom:var(--space-2);font-size:var(--text-sm);">✅ Foods to Favor</h4>
        ${d.foods.favor.map(f => `<div style="font-size:var(--text-xs);color:var(--accent-green);padding:var(--space-1) 0;">• ${f}</div>`).join('')}
      </div>
      <div class="card"><h4 style="margin-bottom:var(--space-2);font-size:var(--text-sm);">❌ Foods to Avoid</h4>
        ${d.foods.avoid.map(f => `<div style="font-size:var(--text-xs);color:var(--accent-coral);padding:var(--space-1) 0;">• ${f}</div>`).join('')}
      </div>
    </div>
    <div class="card"><h4 style="margin-bottom:var(--space-2);">🌿 Recommended Herbs</h4>
      <div style="display:flex;flex-wrap:wrap;gap:var(--space-2);">${d.herbs.map(h => `<span class="badge badge-green">${h}</span>`).join('')}</div>
    </div>
    <div class="card"><h4 style="margin-bottom:var(--space-2);">🧘 Lifestyle Tips</h4>
      ${d.lifestyle.map(l => `<div style="font-size:var(--text-sm);color:var(--text-secondary);padding:var(--space-1) 0;">• ${l}</div>`).join('')}
    </div>
    <button class="btn btn-secondary btn-block" id="retake-quiz">Retake Quiz</button>
  </div>`;
}

function renderFaceMap() {
    return `<div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">
    <div class="card" style="text-align:center;">
      <h4 style="margin-bottom:var(--space-2);">Chinese Face Mapping</h4>
      <p style="font-size:var(--text-xs);color:var(--text-secondary);margin-bottom:var(--space-4);">Each facial zone connects to internal organs via TCM meridians. Tap a zone to learn more.</p>
      <div class="face-map" style="background:var(--bg-glass-heavy);border-radius:var(--radius-xl);border:1px solid var(--border-subtle);">
        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:80px;opacity:0.15;">👤</div>
        ${faceMappingZones.map(z => `<div class="face-map-zone" data-zone="${z.id}" style="top:${z.position.top};left:${z.position.left};width:${z.position.width};height:${z.position.height};border-radius:var(--radius-md);">
          <span class="zone-label">${z.name}</span>
        </div>`).join('')}
      </div>
    </div>
    <div id="zone-detail"></div>
    <div class="section-heading"><h3>All Zones</h3></div>
    ${faceMappingZones.map(z => `<div class="card card-sm zone-list-item" data-zone="${z.id}" style="cursor:pointer;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div><div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${z.name}</div><div style="font-size:var(--text-xs);color:var(--text-tertiary);">${z.organ}</div></div>
        <span style="color:var(--text-tertiary);font-size:12px;">→</span>
      </div>
    </div>`).join('')}
  </div>`;
}

function renderTongue() {
    return `<div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">
    <div class="card" style="text-align:center;">
      <div style="font-size:48px;margin-bottom:var(--space-2);">👅</div>
      <h4>Tongue Diagnosis</h4>
      <p style="font-size:var(--text-xs);color:var(--text-secondary);">In TCM, the tongue reflects internal organ health</p>
    </div>
    ${tongueDiagnosis.map(t => `<div class="card card-sm">
      <h4 style="font-size:var(--text-sm);margin-bottom:var(--space-1);color:var(--accent-amber);">${t.condition}</h4>
      <p style="font-size:var(--text-xs);color:var(--text-secondary);margin-bottom:var(--space-2);">${t.meaning}</p>
      <p style="font-size:var(--text-xs);color:var(--accent-teal);">💡 ${t.recommendation}</p>
    </div>`).join('')}
  </div>`;
}

function setupEMHandlers() {
    document.querySelectorAll('.quiz-option').forEach(opt => {
        opt.addEventListener('click', () => {
            quizAnswers.push(opt.dataset.dosha);
            quizStep++;
            const c = document.getElementById('em-content');
            c.innerHTML = renderDoshaTab();
            setupEMHandlers();
        });
    });
    document.getElementById('retake-quiz')?.addEventListener('click', () => {
        store.set('dosha', null); quizStep = 0; quizAnswers = [];
        const c = document.getElementById('em-content');
        c.innerHTML = renderQuiz(); setupEMHandlers();
    });
    document.querySelectorAll('.face-map-zone, .zone-list-item').forEach(el => {
        el.addEventListener('click', () => {
            const zone = faceMappingZones.find(z => z.id === el.dataset.zone);
            if (zone) {
                const detail = document.getElementById('zone-detail');
                if (detail) {
                    detail.innerHTML = `<div class="card animate-fade-in-up" style="border-left:3px solid var(--accent-teal);">
            <h4 style="margin-bottom:var(--space-1);">${zone.name}</h4>
            <p style="font-size:var(--text-xs);color:var(--accent-purple);margin-bottom:var(--space-2);">${zone.tcmMeridian}</p>
            <p style="font-size:var(--text-sm);font-weight:var(--weight-semibold);margin-bottom:var(--space-1);">Connected Organ: ${zone.organ}</p>
            <div style="margin:var(--space-2) 0;">
              <p style="font-size:var(--text-xs);font-weight:var(--weight-semibold);margin-bottom:var(--space-1);">Signs to Watch:</p>
              ${zone.signs.map(s => `<p style="font-size:var(--text-xs);color:var(--text-secondary);padding:var(--space-1) 0;">• ${s}</p>`).join('')}
            </div>
            <div><p style="font-size:var(--text-xs);font-weight:var(--weight-semibold);margin-bottom:var(--space-1);">Recommendations:</p>
              ${zone.recommendations.map(r => `<p style="font-size:var(--text-xs);color:var(--accent-teal);padding:var(--space-1) 0;">✨ ${r}</p>`).join('')}
            </div>
          </div>`;
                    detail.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
}
