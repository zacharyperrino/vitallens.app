// Body Scanner — AI Biomarker Detection System
// 5 scan modes: Heart Rate, Face Scan, Eye Check, Skin Check, Body Scan

import { icons } from '../icons.js';
import { CameraSystem, QualityGate } from '../utils/camera-system.js';
import { RPPGEngine, analyzeFace, analyzeEye, analyzeSkin, analyzeBodyComposition } from '../utils/biomarker-engine.js';
import { createRadarChart } from '../utils/charts.js';
import { bodyScans, hrReadings } from '../lib/db.js'; // ← Supabase

let activeMode = 'face';
let camera = null;
let rppgEngine = null;
let isScanning = false;

const MODES = [
  { id: 'heart', icon: '💓', label: 'Heart Rate', desc: 'Measure HR via face video', guide: 'face', facingMode: 'user' },
  { id: 'face', icon: '👤', label: 'Face Scan', desc: 'Skin, pallor, hydration', guide: 'face', facingMode: 'user' },
  { id: 'eye', icon: '👁️', label: 'Eye Check', desc: 'Jaundice & anemia signals', guide: 'eye', facingMode: 'user' },
  { id: 'skin', icon: '🔬', label: 'Skin Check', desc: 'Lesion risk triage (ABCDE)', guide: 'skin', facingMode: 'environment' },
  { id: 'body', icon: '🧍', label: 'Body Scan', desc: 'Posture & composition', guide: 'body', facingMode: 'environment' },
];

export async function renderBodyScanner() {
  if (camera) { camera.stop(); camera = null; }
  isScanning = false;

  const content = document.getElementById('page-content');

  // ── Load scan history from Supabase ─────────────────────
  let history = [];
  let recentHR = [];
  try { history = await bodyScans.getRecent(8); } catch (e) { console.warn('Could not load body scans:', e.message); }
  try { recentHR = await hrReadings.getRecent(7); } catch (e) { console.warn('Could not load HR readings:', e.message); }

  content.innerHTML = `
    <div class="body-scanner stagger-children">
      <div class="page-header">
        <h1>🔬 Biomarker Scanner</h1>
        <p>AI-powered health signal analysis</p>
      </div>

      <!-- Mode Selector -->
      <div class="mode-selector" id="mode-selector">
        ${MODES.map(m => `
          <div class="mode-card ${m.id === activeMode ? 'active' : ''}" data-mode="${m.id}">
            <div class="mode-icon">${m.icon}</div>
            <div class="mode-label">${m.label}</div>
          </div>
        `).join('')}
      </div>

      <!-- Scanner Area -->
      <div id="scanner-area" style="margin-top:var(--space-4);">
        ${renderScannerForMode(activeMode)}
      </div>

      <!-- Results Area -->
      <div id="scan-results" class="hidden"></div>

      <!-- Clinical Disclaimer -->
      <div class="disclaimer-banner" style="margin-top:var(--space-4);">
        <span class="icon">⚠️</span>
        <span>This tool provides screening signals only — it is <strong>not a medical diagnosis</strong>. Consult a qualified healthcare provider for clinical evaluation.</span>
      </div>

      <!-- HR Trend (if readings exist) -->
      ${recentHR.length >= 2 ? renderHRTrend(recentHR) : ''}

      <!-- Scan History -->
      <div class="section-heading" style="margin-top:var(--space-5);">
        <h3>Scan History</h3>
        <span class="badge badge-purple">${history.length}</span>
      </div>
      <div id="scan-history" style="display:flex;flex-direction:column;gap:var(--space-3);">
        ${renderScanHistory(history)}
      </div>
    </div>`;

  setupModeSelector();
}

// ═══════════════════════════════════════════════════
//  Scanner UI
// ═══════════════════════════════════════════════════

function renderScannerForMode(mode) {
  const m = MODES.find(x => x.id === mode);
  const instructions = getInstructions(mode);

  if (mode === 'heart') {
    return `
      <div class="card" style="padding:0;overflow:hidden;">
        <div class="scanner-viewfinder" id="viewfinder">
          <div class="scanner-guide-overlay"><div class="guide-face"></div></div>
          <div class="capture-progress" id="capture-progress"></div>
          <div class="quality-bar" id="quality-bar"></div>
          <div class="scanner-status" id="scanner-status">
            <div class="scanner-status-dot amber"></div>
            <span>Tap Start to begin</span>
          </div>
        </div>
      </div>
      <div class="card" style="margin-top:var(--space-3);">
        <div style="display:flex;align-items:center;gap:var(--space-3);margin-bottom:var(--space-3);">
          <span style="font-size:24px;">💓</span>
          <div><h4>Heart Rate Measurement</h4><p style="font-size:var(--text-xs);color:var(--text-tertiary);">${instructions}</p></div>
        </div>
        <div id="hr-live-display" style="display:none;text-align:center;padding:var(--space-4) 0;">
          <div class="hr-display" style="justify-content:center;">
            <div class="hr-pulse">💓</div>
            <div><div class="hr-value" id="hr-value">--</div><div class="hr-label">BPM</div></div>
          </div>
          <div style="margin-top:var(--space-3);">
            <div class="progress-bar" style="height:6px;"><div class="progress-fill" id="hr-progress" style="width:0%;background:var(--accent-coral);"></div></div>
            <p style="font-size:var(--text-xs);color:var(--text-tertiary);margin-top:var(--space-2);" id="hr-status-text">Recording...</p>
          </div>
        </div>
        <button class="btn btn-primary btn-block" id="start-scan-btn">
          ${icons.camera} Start Heart Rate Scan
        </button>
      </div>`;
  }

  return `
    <div class="card" style="padding:0;overflow:hidden;">
      <div class="scanner-viewfinder" id="viewfinder">
        <div class="scanner-guide-overlay"><div class="guide-${m.guide}"></div></div>
        <div class="quality-bar" id="quality-bar"></div>
        <div class="scanner-status" id="scanner-status">
          <div class="scanner-status-dot amber"></div>
          <span>Ready to scan</span>
        </div>
      </div>
    </div>
    <div class="card" style="margin-top:var(--space-3);">
      <div style="display:flex;align-items:center;gap:var(--space-3);margin-bottom:var(--space-3);">
        <span style="font-size:24px;">${m.icon}</span>
        <div><h4>${m.label}</h4><p style="font-size:var(--text-xs);color:var(--text-tertiary);">${instructions}</p></div>
      </div>
      <div style="display:flex;gap:var(--space-3);">
        <button class="btn btn-primary" id="start-scan-btn" style="flex:1;">
          ${icons.camera} Start Camera
        </button>
        <label class="btn btn-secondary" style="flex:1;cursor:pointer;">
          📁 Upload Photo
          <input type="file" accept="image/*" id="upload-input" style="display:none;">
        </label>
      </div>
    </div>`;
}

function getInstructions(mode) {
  const map = {
    heart: 'Hold your face still in the oval for 15 seconds. Stay in even lighting. Avoid movement.',
    face: 'Position your face in the oval. Ensure good, even lighting. Remove glasses if possible.',
    eye: 'Bring your eye close to the camera. Focus on one eye at a time. Pull down lower eyelid slightly.',
    skin: 'Position the skin area of concern in the frame. Get close but keep focus sharp.',
    body: 'Stand upright, face forward. Full body visible. Use rear camera for best results.',
  };
  return map[mode] || '';
}

function setupModeSelector() {
  document.querySelectorAll('.mode-card').forEach(card => {
    card.addEventListener('click', () => {
      if (camera) { camera.stop(); camera = null; }
      isScanning = false;
      activeMode = card.dataset.mode;
      document.querySelectorAll('.mode-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      document.getElementById('scanner-area').innerHTML = renderScannerForMode(activeMode);
      document.getElementById('scan-results').classList.add('hidden');
      document.getElementById('scan-results').innerHTML = '';
      attachScanHandlers();
    });
  });
  attachScanHandlers();
}

function attachScanHandlers() {
  document.getElementById('start-scan-btn')?.addEventListener('click', () => startCameraScan());
  document.getElementById('upload-input')?.addEventListener('change', (e) => {
    if (e.target.files?.[0]) processUploadedImage(e.target.files[0]);
  });
}

// ═══════════════════════════════════════════════════
//  Camera Scanning
// ═══════════════════════════════════════════════════

async function startCameraScan() {
  if (isScanning) return;
  isScanning = true;

  const m = MODES.find(x => x.id === activeMode);
  const viewfinder = document.getElementById('viewfinder');
  const statusEl = document.getElementById('scanner-status');
  const startBtn = document.getElementById('start-scan-btn');

  startBtn.disabled = true;
  startBtn.innerHTML = '<div class="spinner" style="width:16px;height:16px;border-width:2px;"></div> Starting camera...';

  camera = new CameraSystem({ facingMode: m.facingMode, frameRate: 30 });
  const started = await camera.start(viewfinder);

  if (!started) {
    showToast('❌ Camera access denied. Please grant camera permission and try again.');
    startBtn.disabled = false;
    startBtn.innerHTML = `${icons.camera} Start Camera`;
    isScanning = false;
    return;
  }

  updateStatus(statusEl, 'green', 'Camera active');

  if (activeMode === 'heart') {
    startHeartRateScan();
  } else {
    startBtn.innerHTML = '📸 Capture & Analyze';
    startBtn.disabled = false;
    startBtn.onclick = () => captureAndAnalyze();
    camera.onFrame(frame => {
      if (!isScanning) return;
      updateQualityIndicators(frame.imageData);
    });
  }
}

function startHeartRateScan() {
  const hrDisplay = document.getElementById('hr-live-display');
  const progressBar = document.getElementById('hr-progress');
  const hrValue = document.getElementById('hr-value');
  const statusText = document.getElementById('hr-status-text');
  const statusEl = document.getElementById('scanner-status');
  const startBtn = document.getElementById('start-scan-btn');

  if (hrDisplay) hrDisplay.style.display = 'block';
  startBtn.style.display = 'none';
  updateStatus(statusEl, 'red', 'Recording HR — hold still');

  rppgEngine = new RPPGEngine();

  rppgEngine.onProgress = (progress) => {
    if (progressBar) progressBar.style.width = `${progress * 100}%`;
    if (statusText) {
      const remaining = Math.ceil((1 - progress) * 15);
      statusText.textContent = `Recording... ${remaining}s remaining`;
    }
    updateCaptureProgressRing(progress);
  };

  rppgEngine.onResult = async (result) => {
    isScanning = false;
    camera.stop();
    camera = null;

    if (hrValue) hrValue.textContent = result.hr;
    if (statusText) statusText.textContent = `Measured: ${result.hr} BPM (${result.quality} quality)`;
    updateStatus(document.getElementById('scanner-status'), 'green', `${result.hr} BPM — ${result.quality}`);

    // ── Save to Supabase ─────────────────────────────────
    try {
      await hrReadings.log({
        hr: result.hr,
        hrv: result.hrv,
        confidence: result.confidence,
        quality: result.quality,
      });
      await bodyScans.log({
        type: 'heart',
        overallScore: result.confidence,
        hr: result.hr,
        hrv: result.hrv,
        confidence: result.confidence,
        quality: result.quality,
      });
      console.log('[BodyScanner] HR reading saved to Supabase');
    } catch (dbErr) {
      console.error('[BodyScanner] Failed to save HR reading:', dbErr.message);
    }
    // ────────────────────────────────────────────────────

    showHeartRateResults(result);
  };

  rppgEngine.start(15000);
  camera.onFrame(frame => {
    if (!rppgEngine?.isRecording) return;
    rppgEngine.addFrame(frame.imageData);
    updateQualityIndicators(frame.imageData);
  });
}

function captureAndAnalyze() {
  if (!camera || !isScanning) return;
  const frame = camera.captureFrame();
  if (!frame) return;

  isScanning = false;
  camera.stop();
  camera = null;

  const viewfinder = document.getElementById('viewfinder');
  if (viewfinder) {
    viewfinder.innerHTML = `
      <img src="${frame.dataUrl}" style="width:100%;height:100%;object-fit:cover;">
      <div class="scanner-line"></div>
      <div class="scanner-status">
        <div class="spinner" style="width:14px;height:14px;border-width:2px;"></div>
        <span>Analyzing biomarkers...</span>
      </div>`;
  }

  setTimeout(async () => {
    let result;
    switch (activeMode) {
      case 'face': result = await analyzeFace(frame.imageData); break;
      case 'eye': result = await analyzeEye(frame.imageData); break;
      case 'skin': result = await analyzeSkin(frame.imageData); break;
      case 'body': result = await analyzeBodyComposition(frame.imageData); break;
      default: result = await analyzeFace(frame.imageData);
    }

    // ── Save to Supabase ─────────────────────────────────
    try {
      await bodyScans.log({
        type: activeMode,
        overallScore: result.overallScore,
        results: result.results,
        recommendations: result.recommendations,
        riskTier: result.riskTier || null,
      });
      console.log('[BodyScanner] Scan saved to Supabase');
    } catch (dbErr) {
      console.error('[BodyScanner] Failed to save scan:', dbErr.message);
    }
    // ────────────────────────────────────────────────────

    showAnalysisResults(result, frame.dataUrl);
  }, 1800);
}

// ═══════════════════════════════════════════════════
//  Upload-based Scanning
// ═══════════════════════════════════════════════════

function processUploadedImage(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    const img = new Image();
    img.onload = async () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

      const viewfinder = document.getElementById('viewfinder');
      if (viewfinder) {
        viewfinder.innerHTML = `
          <img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;">
          <div class="scanner-line"></div>
          <div class="scanner-status">
            <div class="spinner" style="width:14px;height:14px;border-width:2px;"></div>
            <span>Analyzing biomarkers...</span>
          </div>`;
      }

      const quality = QualityGate.assess(imageData);
      if (!quality.pass) {
        showToast(`⚠️ Image quality issues: ${quality.blur.label} sharpness. Results may be less accurate.`);
      }

      setTimeout(async () => {
        let result;
        switch (activeMode) {
          case 'face': result = analyzeFace(imageData); break;
          case 'eye': result = analyzeEye(imageData); break;
          case 'skin': result = analyzeSkin(imageData); break;
          case 'body': result = analyzeBodyComposition(imageData); break;
          default: result = analyzeFace(imageData);
        }

        // ── Save to Supabase ─────────────────────────────────
        try {
          await bodyScans.log({
            type: activeMode,
            overallScore: result.overallScore,
            results: result.results,
            recommendations: result.recommendations,
            riskTier: result.riskTier || null,
          });
        } catch (dbErr) {
          console.error('[BodyScanner] Failed to save scan:', dbErr.message);
        }
        // ────────────────────────────────────────────────────

        showAnalysisResults(result, e.target.result);
      }, 2000);
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

// ═══════════════════════════════════════════════════
//  Results Display
// ═══════════════════════════════════════════════════

function showHeartRateResults(result) {
  const resultsDiv = document.getElementById('scan-results');
  resultsDiv.classList.remove('hidden');

  const hrZone = result.hr < 60 ? 'Resting' : result.hr < 100 ? 'Normal' : result.hr < 140 ? 'Elevated' : 'High';
  const zoneColor = result.hr < 60 ? 'var(--accent-blue)' : result.hr < 100 ? 'var(--accent-green)' : result.hr < 140 ? 'var(--accent-amber)' : 'var(--accent-coral)';

  resultsDiv.innerHTML = `
    <div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);margin-top:var(--space-4);">
      <div class="card" style="text-align:center;">
        <h3 style="margin-bottom:var(--space-4);">💓 Heart Rate Results</h3>
        <div class="hr-display" style="justify-content:center;margin-bottom:var(--space-4);">
          <div class="hr-pulse">💓</div>
          <div>
            <div class="hr-value" style="color:${zoneColor};">${result.hr}</div>
            <div class="hr-label">BPM</div>
          </div>
        </div>
        <div style="display:flex;justify-content:center;gap:var(--space-4);">
          <div class="stat-card" style="align-items:center;">
            <div class="stat-value" style="font-size:var(--text-xl);">${result.hrv}</div>
            <div class="stat-label">HRV (ms)</div>
          </div>
          <div class="stat-card" style="align-items:center;">
            <div class="stat-value" style="font-size:var(--text-xl);color:${zoneColor};">${hrZone}</div>
            <div class="stat-label">Zone</div>
          </div>
          <div class="stat-card" style="align-items:center;">
            <div class="stat-value" style="font-size:var(--text-xl);">${result.confidence}%</div>
            <div class="stat-label">Confidence</div>
          </div>
        </div>
      </div>
      <div class="card card-sm">
        <div style="display:flex;align-items:center;gap:var(--space-2);margin-bottom:var(--space-2);">
          <span class="badge ${result.quality === 'Good' ? 'badge-green' : result.quality === 'Fair' ? 'badge-amber' : 'badge-coral'}">${result.quality} Signal</span>
          <span style="font-size:var(--text-xs);color:var(--text-tertiary);">${result.sampleRate} fps over ${result.duration}s</span>
        </div>
        <p style="font-size:var(--text-xs);color:var(--text-secondary);line-height:1.5;">${getHRInterpretation(result.hr, hrZone)}</p>
      </div>
      <div class="disclaimer-banner">
        <span class="icon">⚠️</span>
        <span>rPPG heart rate measurement via camera is an estimation technique. For clinical accuracy, use a dedicated pulse oximeter or medical-grade device.</span>
      </div>
      <button class="btn btn-primary btn-block" id="new-scan-btn">🔄 New Scan</button>
    </div>`;

  resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
  document.getElementById('new-scan-btn')?.addEventListener('click', () => renderBodyScanner());
}

function getHRInterpretation(hr, zone) {
  if (hr < 50) return 'Very low resting heart rate. Common in highly trained athletes. If you experience dizziness or fatigue, consult a doctor.';
  if (hr < 60) return 'Low resting heart rate (bradycardia range). This can be normal for fit individuals. Monitor for symptoms.';
  if (hr < 80) return 'Excellent resting heart rate. This suggests good cardiovascular fitness and autonomic nervous system health.';
  if (hr < 100) return 'Normal resting heart rate. Within healthy range for most adults.';
  if (hr < 120) return 'Slightly elevated heart rate. Could indicate recent activity, stress, caffeine, or dehydration.';
  return 'Elevated heart rate. If at rest, consider monitoring stress, hydration, and caffeine intake. Seek medical advice if persistent.';
}

function showAnalysisResults(result, previewUrl) {
  const resultsDiv = document.getElementById('scan-results');
  resultsDiv.classList.remove('hidden');

  const viewfinder = document.getElementById('viewfinder');
  if (viewfinder && previewUrl) {
    viewfinder.innerHTML = `
      <img src="${previewUrl}" style="width:100%;height:100%;object-fit:cover;">
      <div style="position:absolute;top:var(--space-3);right:var(--space-3);">
        <div class="badge badge-green">${icons.check} Complete</div>
      </div>`;
  }

  const sColors = { good: 'var(--accent-green)', moderate: 'var(--accent-amber)', concerning: 'var(--accent-coral)' };
  const sLabels = { good: 'Healthy', moderate: 'Monitor', concerning: 'Attention' };
  const m = MODES.find(x => x.id === activeMode);

  const radarData = result.results.map(r => ({
    label: r.name.split(' ')[0].substring(0, 8),
    value: r.severity === 'good' ? 90 : r.severity === 'moderate' ? 55 : 25,
  }));

  resultsDiv.innerHTML = `
    <div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);margin-top:var(--space-4);">
      <div class="card" style="text-align:center;">
        <h3 style="margin-bottom:var(--space-2);">${m.icon} ${m.label} Analysis</h3>
        <div style="font-family:var(--font-heading);font-size:var(--text-4xl);font-weight:var(--weight-extrabold);color:${result.overallScore >= 80 ? 'var(--accent-green)' : result.overallScore >= 55 ? 'var(--accent-amber)' : 'var(--accent-coral)'};">${result.overallScore}%</div>
        <p style="font-size:var(--text-sm);color:var(--text-secondary);">Overall Health Signal Score</p>
        ${result.riskTier ? `<div style="margin-top:var(--space-2);"><span class="badge badge-${result.riskColor}">${result.riskTier}</span></div>` : ''}
        <div style="display:flex;justify-content:center;gap:var(--space-3);margin-top:var(--space-3);">
          <span class="badge badge-green">${result.results.filter(r => r.severity === 'good').length} Healthy</span>
          <span class="badge badge-amber">${result.results.filter(r => r.severity === 'moderate').length} Monitor</span>
          <span class="badge badge-coral">${result.results.filter(r => r.severity === 'concerning').length} Attention</span>
        </div>
      </div>

      ${radarData.length >= 3 ? `
      <div class="card">
        <h4 style="margin-bottom:var(--space-3);text-align:center;">Biomarker Radar</h4>
        <div style="display:flex;justify-content:center;">${createRadarChart(radarData, 220)}</div>
      </div>` : ''}

      <div class="section-heading"><h3>Detailed Findings</h3></div>
      ${result.results.map(r => `
      <div class="card card-sm" style="border-left:3px solid ${sColors[r.severity]};">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:var(--space-2);">
          <div style="display:flex;align-items:center;gap:var(--space-2);">
            <span style="font-size:20px;">${r.icon}</span>
            <div>
              <h4 style="font-size:var(--text-sm);">${r.name}</h4>
              <span style="font-size:var(--text-xs);color:var(--text-tertiary);">${r.zone}</span>
            </div>
          </div>
          <span class="badge badge-${r.severity === 'good' ? 'green' : r.severity === 'moderate' ? 'amber' : 'coral'}">${sLabels[r.severity]}</span>
        </div>
        <p style="font-size:var(--text-xs);color:var(--text-secondary);line-height:1.5;margin-bottom:var(--space-2);">${r.finding}</p>
        ${r.guidance ? `<p style="font-size:var(--text-xs);color:var(--accent-teal);line-height:1.4;">${r.guidance}</p>` : ''}
        <div style="margin-top:var(--space-2);display:flex;align-items:center;gap:var(--space-2);">
          <div class="progress-bar" style="flex:1;height:4px;">
            <div class="progress-fill" style="width:${r.confidence}%;background:${sColors[r.severity]};"></div>
          </div>
          <span style="font-size:var(--text-xs);color:var(--text-tertiary);">${r.confidence}% confidence</span>
        </div>
      </div>`).join('')}

      <div class="section-heading"><h3>Clinical Recommendations</h3></div>
      ${result.recommendations.map(rec => `
      <div class="card card-sm" style="border-left:3px solid ${rec.priority === 'high' ? 'var(--accent-coral)' : rec.priority === 'medium' ? 'var(--accent-amber)' : 'var(--accent-green)'};">
        <span style="font-size:var(--text-xs);font-weight:var(--weight-semibold);text-transform:uppercase;color:${rec.priority === 'high' ? 'var(--accent-coral)' : rec.priority === 'medium' ? 'var(--accent-amber)' : 'var(--accent-green)'};">${rec.priority} priority</span>
        <p style="font-size:var(--text-sm);color:var(--text-secondary);line-height:1.5;margin-top:var(--space-1);">${rec.text}</p>
      </div>`).join('')}

      <div class="disclaimer-banner">
        <span class="icon">⚠️</span>
        <span>${result.disclaimer}</span>
      </div>

      <button class="btn btn-primary btn-block" id="new-scan-btn" style="margin-bottom:var(--space-4);">🔄 New Scan</button>
    </div>`;

  resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
  document.getElementById('new-scan-btn')?.addEventListener('click', () => renderBodyScanner());
}

// ═══════════════════════════════════════════════════
//  HR Trend Chart
// ═══════════════════════════════════════════════════

function renderHRTrend(readings) {
  const avg = Math.round(readings.reduce((s, r) => s + r.hr, 0) / readings.length);
  return `
    <div class="card" style="margin-top:var(--space-4);">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-3);">
        <h4>📊 Recent HR Trend</h4>
        <span style="font-size:var(--text-sm);font-weight:var(--weight-semibold);color:var(--accent-teal);">Avg: ${avg} BPM</span>
      </div>
      <div style="display:flex;align-items:flex-end;gap:var(--space-2);height:60px;">
        ${readings.slice().reverse().map(r => {
    const h = Math.max(10, Math.min(100, (r.hr - 40) / 1.2));
    const c = r.hr < 100 ? 'var(--accent-teal)' : 'var(--accent-amber)';
    return `<div style="flex:1;height:${h}%;background:${c};border-radius:var(--radius-sm) var(--radius-sm) 0 0;opacity:0.8;" title="${r.hr} BPM"></div>`;
  }).join('')}
      </div>
      <p style="font-size:var(--text-xs);color:var(--text-tertiary);margin-top:var(--space-2);">${readings.length} readings</p>
    </div>`;
}

// ═══════════════════════════════════════════════════
//  Scan History
// ═══════════════════════════════════════════════════

function renderScanHistory(history) {
  if (history.length === 0) {
    return `<div class="card" style="text-align:center;padding:var(--space-8);">
      <div style="font-size:40px;margin-bottom:var(--space-3);">🔬</div>
      <h4>No scans yet</h4>
      <p style="font-size:var(--text-sm);color:var(--text-tertiary);">Select a mode above and take your first scan</p>
    </div>`;
  }

  return history.map(s => {
    const m = MODES.find(x => x.id === s.scan_type) || { icon: '🔬', label: s.scan_type };
    const t = s.scanned_at
      ? new Date(s.scanned_at).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
      : 'Recently';
    const scoreColor = (s.overall_score || 0) >= 75 ? 'var(--accent-green)' : (s.overall_score || 0) >= 50 ? 'var(--accent-amber)' : 'var(--accent-coral)';

    return `<div class="card card-sm">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="display:flex;align-items:center;gap:var(--space-3);">
          <div style="width:36px;height:36px;border-radius:var(--radius-md);background:var(--accent-purple-dim);display:flex;align-items:center;justify-content:center;font-size:18px;">${m.icon}</div>
          <div>
            <div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${m.label}</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${t}${s.hr ? ' • ' + s.hr + ' BPM' : ''}${s.risk_tier ? ' • ' + s.risk_tier : ''}</div>
          </div>
        </div>
        <div style="font-family:var(--font-heading);font-weight:var(--weight-bold);color:${scoreColor};">
          ${s.scan_type === 'heart' && s.hr ? s.hr + '<span style="font-size:var(--text-xs);color:var(--text-tertiary);"> BPM</span>' : (s.overall_score || 0) + '%'}
        </div>
      </div>
    </div>`;
  }).join('');
}

// ═══════════════════════════════════════════════════
//  UI Helpers
// ═══════════════════════════════════════════════════

function updateQualityIndicators(imageData) {
  const bar = document.getElementById('quality-bar');
  if (!bar) return;
  const quality = QualityGate.assess(imageData);
  const face = QualityGate.detectFaceRegion(imageData);
  const dotColor = (pass) => pass ? 'green' : 'red';
  bar.innerHTML = `
    <div class="quality-dot"><div class="scanner-status-dot ${dotColor(quality.blur.pass)}"></div>${quality.blur.label}</div>
    <div class="quality-dot"><div class="scanner-status-dot ${dotColor(quality.exposure.pass)}"></div>${quality.exposure.label}</div>
    ${activeMode === 'face' || activeMode === 'heart' ? `<div class="quality-dot"><div class="scanner-status-dot ${dotColor(face.detected)}"></div>${face.detected ? 'Face OK' : 'No Face'}</div>` : ''}
  `;
  const statusEl = document.getElementById('scanner-status');
  if (statusEl && activeMode !== 'heart') {
    const allPass = quality.pass && (activeMode !== 'face' || face.detected);
    updateStatus(statusEl, allPass ? 'green' : 'amber', allPass ? 'Ready — tap Capture' : 'Adjust position/lighting');
  }
}

function updateStatus(el, color, text) {
  if (!el) return;
  el.innerHTML = `<div class="scanner-status-dot ${color} ${color === 'red' ? 'pulse' : ''}"></div><span>${text}</span>`;
}

function updateCaptureProgressRing(progress) {
  const container = document.getElementById('capture-progress');
  if (!container) return;
  const r = 22, circumference = 2 * Math.PI * r;
  const offset = circumference * (1 - progress);
  container.innerHTML = `
    <svg width="52" height="52">
      <circle cx="26" cy="26" r="${r}" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="3"/>
      <circle cx="26" cy="26" r="${r}" fill="none" stroke="var(--accent-coral)" stroke-width="3"
        stroke-dasharray="${circumference}" stroke-dashoffset="${offset}" stroke-linecap="round"/>
      <text x="26" y="30" text-anchor="middle" fill="white" font-size="11" font-weight="600">${Math.round(progress * 100)}%</text>
    </svg>`;
}

function showToast(msg) {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div'); t.className = 'toast'; t.innerHTML = `<span>${msg}</span>`;
  c.appendChild(t); setTimeout(() => { t.classList.add('removing'); setTimeout(() => t.remove(), 300); }, 4000);
}