import { store } from '../store.js';
import { icons } from '../icons.js';
import { createLineChart, createBarChart, createRadarChart, createRingProgress } from '../utils/charts.js';
import { computeHealthScore } from '../utils/health-score.js';

export function renderAnalytics() {
  const content = document.getElementById('page-content');
  const data = store.getAll();
  const health = computeHealthScore(data);
  const b = health.breakdown;

  content.innerHTML = `
    <div class="analytics stagger-children">
      <div class="page-header"><h1>📊 Analytics</h1><p>Trends, correlations & health predictions</p></div>

      <!-- Score Breakdown -->
      <div class="card" style="margin-bottom:var(--space-5);">
        <h4 style="margin-bottom:var(--space-4);">Health Score Breakdown</h4>
        <div style="display:flex;justify-content:center;margin-bottom:var(--space-4);">
          ${createRadarChart([
    { label: 'Nutrition', value: b.nutrition },
    { label: 'Exercise', value: b.exercise },
    { label: 'Sleep', value: b.sleep },
    { label: 'Habits', value: b.habits },
    { label: 'Body', value: b.bodyMarkers },
    { label: 'Gut', value: b.gutHealth },
    { label: 'Environ.', value: b.environment },
    { label: 'Mental', value: b.mentalWellness },
  ], 240)}
        </div>
      </div>

      <!-- Category Scores -->
      <div class="section-heading"><h3>Category Scores</h3></div>
      <div style="display:flex;flex-direction:column;gap:var(--space-3);margin-bottom:var(--space-5);">
        ${renderScoreBar('🥗 Nutrition', b.nutrition, 'var(--accent-teal)')}
        ${renderScoreBar('🏃 Exercise', b.exercise, 'var(--accent-blue)')}
        ${renderScoreBar('😴 Sleep', b.sleep, 'var(--accent-purple)')}
        ${renderScoreBar('🧬 Habits', b.habits, 'var(--accent-amber)')}
        ${renderScoreBar('🔬 Biomarkers', b.bodyMarkers, 'var(--accent-coral)')}
        ${renderScoreBar('🧪 Gut Health', b.gutHealth, 'var(--accent-green)')}
        ${renderScoreBar('🌍 Environment', b.environment, 'var(--accent-blue)')}
        ${renderScoreBar('🧠 Mental', b.mentalWellness, 'var(--accent-purple)')}
      </div>

      <!-- Weekly Trend -->
      <div class="card" style="margin-bottom:var(--space-5);">
        <h4 style="margin-bottom:var(--space-3);">Weekly Health Trend</h4>
        ${createLineChart(data.weeklyScores || [72, 74, 71, 76, 78, 75, 78], 340, 100)}
        <div style="display:flex;justify-content:space-between;margin-top:var(--space-2);">
          ${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => `<span style="font-size:var(--text-xs);color:var(--text-tertiary);">${d}</span>`).join('')}
        </div>
      </div>

      <!-- Nutrition Trend -->
      <div class="card" style="margin-bottom:var(--space-5);">
        <h4 style="margin-bottom:var(--space-3);">Calorie Intake (7 Days)</h4>
        ${createBarChart([
    { label: 'M', value: 1920, color: 'var(--accent-teal)' },
    { label: 'T', value: 2100, color: 'var(--accent-teal)' },
    { label: 'W', value: 1750, color: 'var(--accent-amber)' },
    { label: 'T', value: 2200, color: 'var(--accent-teal)' },
    { label: 'F', value: 2400, color: 'var(--accent-coral)' },
    { label: 'S', value: 1980, color: 'var(--accent-teal)' },
    { label: 'S', value: 1847, color: 'var(--accent-teal)' },
  ], 340, 100)}
      </div>

      <!-- Correlations -->
      <div class="section-heading"><h3>Correlations</h3></div>
      <div style="display:flex;flex-direction:column;gap:var(--space-3);margin-bottom:var(--space-5);">
        ${renderCorrelation('😴 Sleep → ⚡ Energy', 82, 'positive', 'Better sleep quality correlates with +23% energy levels')}
        ${renderCorrelation('🥗 Diet → 🔬 Skin', 74, 'positive', 'Plant-based meals improving skin biomarkers by 12%')}
        ${renderCorrelation('🍺 Alcohol → 😴 Sleep', 68, 'negative', 'Alcohol consumption reducing sleep quality by 15%')}
        ${renderCorrelation('🏃 Exercise → 🧠 Mental', 89, 'positive', 'Regular exercise boosting mental wellness score by 18%')}
      </div>

      <!-- Predictions -->
      <div class="section-heading"><h3>Health Predictions</h3></div>
      <div style="display:flex;flex-direction:column;gap:var(--space-3);margin-bottom:var(--space-5);">
        <div class="card card-sm" style="border-left:3px solid var(--accent-green);">
          <div style="display:flex;align-items:center;gap:var(--space-2);margin-bottom:var(--space-1);">
            <span>📈</span><h4 style="font-size:var(--text-sm);">30-Day Projection</h4>
          </div>
          <p style="font-size:var(--text-xs);color:var(--text-secondary);">If current trends continue, your health score is projected to reach <strong style="color:var(--accent-green);">${Math.min(98, health.overall + 8)}</strong> in 30 days.</p>
        </div>
        <div class="card card-sm" style="border-left:3px solid var(--accent-amber);">
          <div style="display:flex;align-items:center;gap:var(--space-2);margin-bottom:var(--space-1);">
            <span>⚡</span><h4 style="font-size:var(--text-sm);">Action Item</h4>
          </div>
          <p style="font-size:var(--text-xs);color:var(--text-secondary);">Increasing daily fiber intake by 8g could improve gut health score by an estimated <strong style="color:var(--accent-teal);">+15 points</strong>.</p>
        </div>
        <div class="card card-sm" style="border-left:3px solid var(--accent-purple);">
          <div style="display:flex;align-items:center;gap:var(--space-2);margin-bottom:var(--space-1);">
            <span>🎯</span><h4 style="font-size:var(--text-sm);">Goal Progress</h4>
          </div>
          <p style="font-size:var(--text-xs);color:var(--text-secondary);">You're on track to achieve your optimal health score target. Consistency in sleep and exercise is key.</p>
        </div>
      </div>

      <!-- Data Summary -->
      <div class="section-heading"><h3>Data Summary</h3></div>
      <div class="grid-2" style="margin-bottom:var(--space-8);">
        <div class="card card-sm" style="text-align:center;">
          <div style="font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:var(--weight-bold);color:var(--accent-teal);">${(data.meals || []).length}</div>
          <div style="font-size:var(--text-xs);color:var(--text-tertiary);">Meals Logged</div>
        </div>
        <div class="card card-sm" style="text-align:center;">
          <div style="font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:var(--weight-bold);color:var(--accent-purple);">${(data.bodyScans || []).length}</div>
          <div style="font-size:var(--text-xs);color:var(--text-tertiary);">Body Scans</div>
        </div>
        <div class="card card-sm" style="text-align:center;">
          <div style="font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:var(--weight-bold);color:var(--accent-green);">${(data.stoolScans || []).length}</div>
          <div style="font-size:var(--text-xs);color:var(--text-tertiary);">Gut Scans</div>
        </div>
        <div class="card card-sm" style="text-align:center;">
          <div style="font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:var(--weight-bold);color:var(--accent-amber);">${(data.labResults || []).length}</div>
          <div style="font-size:var(--text-xs);color:var(--text-tertiary);">Lab Results</div>
        </div>
        <div class="card card-sm" style="text-align:center;">
          <div style="font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:var(--weight-bold);color:var(--accent-blue);">${(data.exerciseLog || []).length}</div>
          <div style="font-size:var(--text-xs);color:var(--text-tertiary);">Workouts</div>
        </div>
      </div>
    </div>`;
}

function renderScoreBar(label, value, color) {
  return `<div class="card card-sm">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-2);">
      <span style="font-size:var(--text-sm);">${label}</span>
      <span style="font-family:var(--font-heading);font-weight:var(--weight-bold);color:${color};">${value}</span>
    </div>
    <div class="progress-bar" style="height:6px;">
      <div class="progress-fill" style="width:${value}%;background:${color};"></div>
    </div>
  </div>`;
}

function renderCorrelation(label, strength, type, description) {
  const color = type === 'positive' ? 'var(--accent-green)' : 'var(--accent-coral)';
  return `<div class="card card-sm">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-2);">
      <span style="font-size:var(--text-sm);">${label}</span>
      <span class="badge" style="background:${color}22;color:${color};">${strength}% ${type === 'positive' ? '↑' : '↓'}</span>
    </div>
    <p style="font-size:var(--text-xs);color:var(--text-tertiary);">${description}</p>
  </div>`;
}
