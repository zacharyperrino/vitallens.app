// ─── GPT-4o Vision — Food Detection Service ──────────────────
// Calls POST /api/vision-scan on the Express server.
// The OpenAI key lives in server/.env — never in the browser.

const API_BASE = 'http://localhost:3001/api';

/**
 * Analyze a food image using GPT-4o Vision (via server proxy).
 * Returns YOLO-compatible detection results.
 *
 * @param {File} imageFile — the photo file from the user
 * @returns {object} — { detections, top5, top, meal_description, meal_context }
 */
export async function analyzeImageWithVision(imageFile) {
    const formData = new FormData();
    formData.append('image', imageFile, imageFile.name || 'meal.jpg');

    const response = await fetch(`${API_BASE}/vision-scan`, {
        method: 'POST',
        body: formData,
        // No Content-Type header — browser sets it automatically with boundary
    });

    if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || `Vision scan failed (${response.status})`);
    }

    const data = await response.json();

    console.log('[VisionAPI] Server response:', data.detections?.length, 'foods detected');
    console.log('[VisionAPI] Meal:', data.meal_description);

    return data;
}