// ─── Health Input Page — Labs, Exercise, Sleep, Habits, Environment ─
import { icons } from '../icons.js';
import { labResults, exerciseLog, sleepLog, habits } from '../lib/db.js'; // ← Supabase
import {
  getStravaConfig, saveStravaConfig, isStravaConfigured,
  isStravaConnected, getAuthorizationUrl, syncActivities,
  importActivity, importAllActivities, disconnectStrava,
} from '../utils/strava.js';

let activeTab = 'labs';

export async function renderHealthInput() {
  const content = document.getElementById('page-content');
  content.innerHTML = `
    <div class="health-input stagger-children">
      <div class="page-header"><h1>📋 Health Data</h1><p>Log your health metrics, labs, habits & more</p></div>
      <div class="tab-bar" id="health-tabs">
        <div class="tab-item active" data-tab="labs">Labs</div>
        <div class="tab-item" data-tab="exercise">Exercise</div>
        <div class="tab-item" data-tab="sleep">Sleep</div>
        <div class="tab-item" data-tab="habits">Habits</div>
        <div class="tab-item" data-tab="env">Environ.</div>
      </div>
      <div id="health-tab-content"><div style="text-align:center;padding:var(--space-8);"><div class="spinner" style="margin:0 auto;"></div></div></div>
    </div>`;

  document.querySelectorAll('#health-tabs .tab-item').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('#health-tabs .tab-item').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      activeTab = tab.dataset.tab;
      renderTabContent();
    });
  });

  renderTabContent();
}

async function renderTabContent() {
  const container = document.getElementById('health-tab-content');
  container.innerHTML = '<div style="text-align:center;padding:var(--space-8);"><div class="spinner" style="margin:0 auto;"></div></div>';

  const renderers = {
    labs: renderLabs,
    exercise: renderExercise,
    sleep: renderSleep,
    habits: renderHabits,
    env: renderEnvironment,
  };

  const html = await (renderers[activeTab] || renderLabs)();
  container.innerHTML = html;
  setupFormHandlers();
}

// ═══════════════════════════════════════
//  Labs Tab
// ═══════════════════════════════════════

async function renderLabs() {
  let labs = [];
  try { labs = await labResults.getAll(); } catch (e) { console.warn('Could not load labs:', e.message); }

  return `<div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">
    <div class="card">
      <h4 style="margin-bottom:var(--space-4);">Add Lab Result</h4>
      <form id="lab-form" style="display:flex;flex-direction:column;gap:var(--space-3);">
        <div class="input-group"><label>Test Name</label>
          <select class="input-field" id="lab-name">
            <option value="">Select test...</option>
            <option>Complete Blood Count (CBC)</option><option>Vitamin D</option><option>Vitamin B12</option>
            <option>Iron / Ferritin</option><option>Thyroid Panel (TSH)</option><option>Cholesterol (Total)</option>
            <option>HDL Cholesterol</option><option>LDL Cholesterol</option><option>Triglycerides</option>
            <option>Fasting Glucose</option><option>HbA1c</option><option>Testosterone</option>
            <option>Cortisol</option><option>Magnesium</option><option>Zinc</option><option>CRP (Inflammation)</option>
          </select>
        </div>
        <div class="grid-2">
          <div class="input-group"><label>Value</label><input class="input-field" type="number" step="any" id="lab-value" placeholder="e.g. 45"></div>
          <div class="input-group"><label>Unit</label><input class="input-field" type="text" id="lab-unit" placeholder="ng/mL"></div>
        </div>
        <div class="input-group"><label>Date</label><input class="input-field" type="date" id="lab-date"></div>
        <button type="submit" class="btn btn-primary btn-block">Save Result</button>
      </form>
    </div>
    <div class="section-heading"><h3>Saved Results</h3><span class="badge badge-teal">${labs.length}</span></div>
    ${labs.length > 0 ? labs.slice(0, 10).map(l => {
    const markers = l.markers || {};
    const firstName = Object.keys(markers)[0];
    const firstMarker = markers[firstName] || {};
    const displayValue = firstMarker.value ?? l.value ?? '—';
    const displayUnit = firstMarker.unit ?? l.unit ?? '';
    const displayName = firstName ?? l.panel_type ?? 'Lab Result';
    const date = l.collected_at || l.uploaded_at?.split('T')[0] || '';
    return `<div class="card card-sm">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div><div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${displayName}</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${date}</div></div>
          <div style="text-align:right;">
            <div style="font-family:var(--font-heading);font-weight:var(--weight-bold);color:var(--accent-teal);">${displayValue}</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${displayUnit}</div>
          </div>
        </div>
      </div>`;
  }).join('') : '<div class="card" style="text-align:center;padding:var(--space-6);"><p style="font-size:var(--text-sm);">No lab results logged yet</p></div>'}
  </div>`;
}

// ═══════════════════════════════════════
//  Exercise Tab + Strava
// ═══════════════════════════════════════

async function renderExercise() {
  let log = [];
  try { log = await exerciseLog.getRecent(8); } catch (e) { console.warn('Could not load exercise:', e.message); }

  const stravaSection = renderStravaSection();

  return `<div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">
    ${stravaSection}
    <div class="card">
      <h4 style="margin-bottom:var(--space-4);">Log Exercise</h4>
      <form id="exercise-form" style="display:flex;flex-direction:column;gap:var(--space-3);">
        <div class="input-group"><label>Activity</label>
          <select class="input-field" id="ex-type">
            <option value="">Select type...</option><option>Running</option><option>Walking</option>
            <option>Weight Training</option><option>Yoga</option><option>Swimming</option>
            <option>Cycling</option><option>HIIT</option><option>Pilates</option>
            <option>Dance</option><option>Sports</option><option>Stretching</option><option>Other</option>
          </select>
        </div>
        <div class="grid-2">
          <div class="input-group"><label>Duration (min)</label><input class="input-field" type="number" id="ex-duration" placeholder="30"></div>
          <div class="input-group"><label>Intensity</label>
            <select class="input-field" id="ex-intensity">
              <option>Low</option><option selected>Moderate</option><option>High</option><option>Very High</option>
            </select>
          </div>
        </div>
        <div class="input-group"><label>Calories Burned (optional)</label><input class="input-field" type="number" id="ex-calories" placeholder="200"></div>
        <button type="submit" class="btn btn-primary btn-block">Log Exercise</button>
      </form>
    </div>
    <div class="section-heading"><h3>Exercise Log</h3><span class="badge badge-teal">${log.length}</span></div>
    ${log.length > 0 ? log.map(renderExerciseCard).join('') : '<div class="card" style="text-align:center;padding:var(--space-6);"><p style="font-size:var(--text-sm);">No exercises logged</p></div>'}
  </div>`;
}

function renderExerciseCard(e) {
  const isStrava = e.source === 'strava';
  return `<div class="card card-sm">
    <div style="display:flex;justify-content:space-between;align-items:center;">
      <div style="display:flex;align-items:center;gap:var(--space-3);">
        <div style="width:36px;height:36px;border-radius:var(--radius-md);background:${isStrava ? 'rgba(252,82,0,0.15)' : 'var(--accent-blue-dim)'};display:flex;align-items:center;justify-content:center;">
          ${isStrava ? `<span style="color:#FC5200;width:20px;height:20px;">${icons.strava}</span>` : '🏃'}
        </div>
        <div>
          <div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${e.name || e.type}</div>
          <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${e.duration}min • ${e.intensity}${e.distance ? ' • ' + e.distance : ''}${e.heart_rate ? ' • ❤️ ' + Math.round(e.heart_rate) + 'bpm' : ''}</div>
        </div>
      </div>
      <span style="font-weight:var(--weight-semibold);color:${isStrava ? '#FC5200' : 'var(--accent-blue)'};">${e.calories || '—'} kcal</span>
    </div>
  </div>`;
}

// ═══════════════════════════════════════
//  Sleep Tab
// ═══════════════════════════════════════

async function renderSleep() {
  let log = [];
  try { log = await sleepLog.getRecent(7); } catch (e) { console.warn('Could not load sleep:', e.message); }

  return `<div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">
    <div class="card">
      <h4 style="margin-bottom:var(--space-4);">Log Sleep</h4>
      <form id="sleep-form" style="display:flex;flex-direction:column;gap:var(--space-3);">
        <div class="grid-2">
          <div class="input-group"><label>Hours Slept</label><input class="input-field" type="number" step="0.5" id="sleep-hours" placeholder="7.5"></div>
          <div class="input-group"><label>Quality</label>
            <select class="input-field" id="sleep-quality">
              <option>Poor</option><option>Fair</option><option selected>Good</option><option>Excellent</option>
            </select>
          </div>
        </div>
        <div class="grid-2">
          <div class="input-group"><label>Bedtime</label><input class="input-field" type="time" id="sleep-bedtime" value="22:30"></div>
          <div class="input-group"><label>Wake Time</label><input class="input-field" type="time" id="sleep-wake" value="06:30"></div>
        </div>
        <div class="input-group"><label>Notes</label><input class="input-field" type="text" id="sleep-notes" placeholder="Any notes..."></div>
        <button type="submit" class="btn btn-primary btn-block">Log Sleep</button>
      </form>
    </div>
    <div class="section-heading"><h3>Sleep Log</h3></div>
    ${log.length > 0 ? log.map(s => `<div class="card card-sm">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="display:flex;align-items:center;gap:var(--space-3);">
          <div style="width:36px;height:36px;border-radius:var(--radius-md);background:var(--accent-purple-dim);display:flex;align-items:center;justify-content:center;">😴</div>
          <div>
            <div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${s.hours}h — ${s.quality}</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${s.bedtime || ''} → ${s.wake_time || s.wake || ''}</div>
          </div>
        </div>
        <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${s.date || ''}</div>
      </div>
    </div>`).join('') : '<div class="card" style="text-align:center;padding:var(--space-6);"><p style="font-size:var(--text-sm);">No sleep data logged</p></div>'}
  </div>`;
}

// ═══════════════════════════════════════
//  Habits Tab
// ═══════════════════════════════════════

async function renderHabits() {
  let h = {};
  try { h = await habits.getToday() || {}; } catch (e) { console.warn('Could not load habits:', e.message); }

  return `<div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">
    <div class="card">
      <h4 style="margin-bottom:var(--space-4);">Lifestyle Habits</h4>
      <div style="display:flex;flex-direction:column;gap:var(--space-4);">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div style="display:flex;align-items:center;gap:var(--space-3);"><span style="font-size:18px;">🚬</span><span style="font-size:var(--text-sm);">Smoking</span></div>
          <div class="toggle ${h.smoking ? 'active' : ''}" id="toggle-smoking"></div>
        </div>
        <div class="divider" style="margin:0;"></div>
        <div class="input-group"><label>🍺 Alcohol Consumption</label>
          <select class="input-field" id="habit-alcohol">
            <option ${h.alcohol === 'none' ? 'selected' : ''}>none</option>
            <option ${h.alcohol === 'light' ? 'selected' : ''}>light</option>
            <option ${h.alcohol === 'moderate' ? 'selected' : ''}>moderate</option>
            <option ${h.alcohol === 'heavy' ? 'selected' : ''}>heavy</option>
          </select>
        </div>
        <div class="input-group"><label>☕ Caffeine Intake</label>
          <select class="input-field" id="habit-caffeine">
            <option ${h.caffeine === 'none' ? 'selected' : ''}>none</option>
            <option ${h.caffeine === 'light' ? 'selected' : ''}>light</option>
            <option ${h.caffeine === 'moderate' ? 'selected' : ''}>moderate</option>
            <option ${h.caffeine === 'heavy' ? 'selected' : ''}>heavy</option>
          </select>
        </div>
        <div class="input-group"><label>💧 Daily Water (glasses)</label>
          <input class="input-field" type="number" id="habit-water" value="${h.water_glasses || 8}" min="0" max="20">
        </div>
        <div class="input-group"><label>😰 Stress Level (1-10)</label>
          <input class="input-field" type="number" id="habit-stress" value="${h.stress_level || ''}" min="1" max="10" placeholder="5">
        </div>
        <div class="input-group"><label>😊 Mood</label>
          <select class="input-field" id="habit-mood">
            <option value="">Select...</option>
            <option ${h.mood === 'great' ? 'selected' : ''}>great</option>
            <option ${h.mood === 'good' ? 'selected' : ''}>good</option>
            <option ${h.mood === 'neutral' ? 'selected' : ''}>neutral</option>
            <option ${h.mood === 'low' ? 'selected' : ''}>low</option>
            <option ${h.mood === 'bad' ? 'selected' : ''}>bad</option>
          </select>
        </div>
        <button class="btn btn-primary btn-block" id="save-habits">Save Today's Habits</button>
      </div>
    </div>
  </div>`;
}

// ═══════════════════════════════════════
//  Environment Tab
// ═══════════════════════════════════════

async function renderEnvironment() {
  // Environment data stays in localStorage for now (low priority for correlation)
  const env = JSON.parse(localStorage.getItem('vitallens_env') || '{}');

  return `<div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">
    <div class="card">
      <h4 style="margin-bottom:var(--space-4);">Environmental Factors</h4>
      <form id="env-form" style="display:flex;flex-direction:column;gap:var(--space-3);">
        <div class="input-group"><label>🌬️ Air Quality</label>
          <select class="input-field" id="env-air">
            <option ${env.airQuality === 'good' ? 'selected' : ''}>good</option>
            <option ${env.airQuality === 'moderate' ? 'selected' : ''}>moderate</option>
            <option ${env.airQuality === 'poor' ? 'selected' : ''}>poor</option>
          </select>
        </div>
        <div class="input-group"><label>💧 Water Quality</label>
          <select class="input-field" id="env-water">
            <option ${env.waterQuality === 'filtered' ? 'selected' : ''}>filtered</option>
            <option ${env.waterQuality === 'tap' ? 'selected' : ''}>tap</option>
            <option ${env.waterQuality === 'well' ? 'selected' : ''}>well</option>
            <option ${env.waterQuality === 'spring' ? 'selected' : ''}>spring</option>
          </select>
        </div>
        <div class="input-group"><label>📍 Location / City</label>
          <input class="input-field" type="text" id="env-location" value="${env.location || ''}" placeholder="e.g. Los Angeles, CA">
        </div>
        <div class="input-group"><label>🌡️ Climate</label>
          <select class="input-field" id="env-climate">
            <option ${env.climate === 'temperate' ? 'selected' : ''}>temperate</option>
            <option ${env.climate === 'tropical' ? 'selected' : ''}>tropical</option>
            <option ${env.climate === 'arid' ? 'selected' : ''}>arid</option>
            <option ${env.climate === 'cold' ? 'selected' : ''}>cold</option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Save Environment Data</button>
      </form>
    </div>
  </div>`;
}

// ═══════════════════════════════════════
//  Strava Section (unchanged from original)
// ═══════════════════════════════════════

function renderStravaSection() {
  const cfg = getStravaConfig();
  const connected = isStravaConnected();
  const configured = isStravaConfigured();
  if (connected) return renderStravaConnected(cfg);
  if (configured) return renderStravaReady();
  return renderStravaSetup();
}

function renderStravaSetup() {
  return `
    <div class="card" style="border:1px solid rgba(252,82,0,0.3);background:linear-gradient(145deg, rgba(252,82,0,0.08), rgba(252,82,0,0.02));">
      <div style="display:flex;align-items:center;gap:var(--space-3);margin-bottom:var(--space-4);">
        <div style="width:44px;height:44px;border-radius:var(--radius-md);background:rgba(252,82,0,0.15);display:flex;align-items:center;justify-content:center;">
          <span style="color:#FC5200;width:24px;height:24px;">${icons.strava}</span>
        </div>
        <div>
          <h4 style="color:#FC5200;margin-bottom:2px;">Connect Strava</h4>
          <p style="font-size:var(--text-xs);color:var(--text-tertiary);margin:0;">Import workouts automatically</p>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:var(--space-3);">
        <div class="input-group"><label>Client ID</label>
          <input class="input-field" type="text" id="strava-client-id" placeholder="Your Strava Client ID">
        </div>
        <div class="input-group"><label>Client Secret</label>
          <input class="input-field" type="password" id="strava-client-secret" placeholder="Your Strava Client Secret">
        </div>
        <button class="btn btn-block" id="strava-save-connect" style="background:linear-gradient(135deg, #FC5200, #FF7A33);color:white;">
          ${icons.link} Save & Connect to Strava
        </button>
      </div>
    </div>`;
}

function renderStravaReady() {
  return `
    <div class="card" style="border:1px solid rgba(252,82,0,0.3);">
      <h4 style="color:#FC5200;margin-bottom:var(--space-3);">Strava Ready</h4>
      <button class="btn btn-block" id="strava-authorize" style="background:linear-gradient(135deg, #FC5200, #FF7A33);color:white;margin-bottom:var(--space-2);">
        Authorize with Strava
      </button>
      <button class="btn btn-ghost btn-block" id="strava-reset" style="font-size:var(--text-xs);">Reset Credentials</button>
    </div>`;
}

function renderStravaConnected(cfg) {
  const lastSync = cfg.lastSync ? timeAgo(cfg.lastSync) : 'Never';
  const activities = cfg.activities || [];
  const unimported = activities.filter(a => !a.imported);

  return `
    <div class="card" style="border:1px solid rgba(252,82,0,0.3);">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--space-4);">
        <div style="display:flex;align-items:center;gap:var(--space-3);">
          <div style="width:44px;height:44px;border-radius:var(--radius-full);background:rgba(252,82,0,0.15);display:flex;align-items:center;justify-content:center;">
            <span style="color:#FC5200;width:24px;height:24px;">${icons.strava}</span>
          </div>
          <div>
            <h4 style="color:#FC5200;margin-bottom:2px;">Strava Connected</h4>
            <p style="font-size:var(--text-xs);color:var(--text-tertiary);margin:0;">${cfg.athleteName || 'Athlete'} • Synced ${lastSync}</p>
          </div>
        </div>
        <span class="badge" style="background:rgba(52,211,153,0.15);color:var(--accent-green);">● Live</span>
      </div>
      <div style="display:flex;gap:var(--space-2);margin-bottom:var(--space-3);">
        <button class="btn btn-block" id="strava-sync" style="background:linear-gradient(135deg, #FC5200, #FF7A33);color:white;flex:2;">
          ${icons.refresh} Sync Now
        </button>
        <button class="btn btn-secondary" id="strava-disconnect" style="flex:1;">${icons.unlink}</button>
      </div>
      ${unimported.length > 0 ? `
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:var(--text-xs);color:var(--text-tertiary);">${unimported.length} ready to import</span>
          <button class="btn btn-sm" id="strava-import-all" style="background:rgba(252,82,0,0.15);color:#FC5200;font-size:var(--text-xs);">Import All</button>
        </div>` : ''}
    </div>
    ${activities.length > 0 ? renderStravaActivities(activities) : ''}`;
}

function renderStravaActivities(activities) {
  return `
    <div class="section-heading"><h3>Strava Activities</h3><span class="badge" style="background:rgba(252,82,0,0.15);color:#FC5200;">${activities.length}</span></div>
    ${activities.slice(0, 10).map(a => {
    const dateStr = new Date(a.date).toLocaleDateString([], { month: 'short', day: 'numeric' });
    return `<div class="card card-sm" style="margin-bottom:var(--space-2);">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div style="display:flex;align-items:center;gap:var(--space-3);flex:1;min-width:0;">
            <div style="width:36px;height:36px;border-radius:var(--radius-md);background:rgba(252,82,0,0.12);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
              ${getActivityEmoji(a.type)}
            </div>
            <div style="min-width:0;">
              <div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${a.name}</div>
              <div style="font-size:var(--text-xs);color:var(--text-tertiary);">
                ${dateStr} • ${a.duration}min${a.distanceKm ? ' • ' + a.distanceKm + 'km' : ''}
              </div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:var(--space-2);flex-shrink:0;">
            <span style="font-size:var(--text-sm);font-weight:var(--weight-semibold);color:#FC5200;">${a.calories || '—'}</span>
            ${a.imported
        ? '<span class="badge badge-green" style="font-size:9px;">Imported</span>'
        : `<button class="btn btn-sm strava-import-btn" data-strava-id="${a.stravaId}" style="background:rgba(252,82,0,0.15);color:#FC5200;font-size:10px;padding:4px 10px;">Import</button>`
      }
          </div>
        </div>
      </div>`;
  }).join('')}`;
}

function getActivityEmoji(type) {
  const map = { Running: '🏃', Walking: '🚶', Cycling: '🚴', Swimming: '🏊', 'Weight Training': '🏋️', Yoga: '🧘', HIIT: '⚡', Pilates: '🤸', Dance: '💃', Sports: '⚽' };
  return map[type] || '🏃';
}

function timeAgo(timestamp) {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

// ═══════════════════════════════════════
//  Event Handlers
// ═══════════════════════════════════════

function setupFormHandlers() {
  // ── Lab form ──
  document.getElementById('lab-form')?.addEventListener('submit', async e => {
    e.preventDefault();
    const name = document.getElementById('lab-name').value;
    const value = document.getElementById('lab-value').value;
    const unit = document.getElementById('lab-unit').value;
    const date = document.getElementById('lab-date').value;
    if (!name || !value) return;

    try {
      await labResults.log({
        panelType: 'manual',
        markers: { [name]: { value: parseFloat(value), unit } },
        collectedAt: date || null,
      });
      showToast('✅ Lab result saved');
      renderTabContent();
    } catch (err) {
      console.error('Lab save failed:', err);
      showToast('❌ Failed to save lab result');
    }
  });

  // ── Exercise form ──
  document.getElementById('exercise-form')?.addEventListener('submit', async e => {
    e.preventDefault();
    const type = document.getElementById('ex-type').value;
    const duration = document.getElementById('ex-duration').value;
    const intensity = document.getElementById('ex-intensity').value;
    const calories = document.getElementById('ex-calories').value;
    if (!type || !duration) return;

    try {
      await exerciseLog.log({
        type,
        duration: parseInt(duration),
        intensity,
        calories: calories ? parseInt(calories) : null,
        source: 'manual',
      });
      showToast('✅ Exercise logged');
      renderTabContent();
    } catch (err) {
      console.error('Exercise save failed:', err);
      showToast('❌ Failed to log exercise');
    }
  });

  // ── Sleep form ──
  document.getElementById('sleep-form')?.addEventListener('submit', async e => {
    e.preventDefault();
    const hours = parseFloat(document.getElementById('sleep-hours').value);
    const quality = document.getElementById('sleep-quality').value;
    const bedtime = document.getElementById('sleep-bedtime').value;
    const wake = document.getElementById('sleep-wake').value;
    const notes = document.getElementById('sleep-notes').value;
    if (!hours) return;

    try {
      await sleepLog.log({ hours, quality, bedtime, wakeTime: wake, notes });
      showToast('✅ Sleep logged');
      renderTabContent();
    } catch (err) {
      console.error('Sleep save failed:', err);
      showToast('❌ Failed to log sleep');
    }
  });

  // ── Habits ──
  document.getElementById('toggle-smoking')?.addEventListener('click', function () {
    this.classList.toggle('active');
  });

  document.getElementById('save-habits')?.addEventListener('click', async () => {
    try {
      await habits.logToday({
        smoking: document.getElementById('toggle-smoking')?.classList.contains('active') || false,
        alcohol: document.getElementById('habit-alcohol')?.value || 'none',
        caffeine: document.getElementById('habit-caffeine')?.value || 'moderate',
        waterGlasses: parseInt(document.getElementById('habit-water')?.value || '8'),
        stressLevel: parseInt(document.getElementById('habit-stress')?.value || '0') || null,
        mood: document.getElementById('habit-mood')?.value || null,
      });
      showToast('✅ Habits saved');
    } catch (err) {
      console.error('Habits save failed:', err);
      showToast('❌ Failed to save habits');
    }
  });

  // ── Environment form ──
  document.getElementById('env-form')?.addEventListener('submit', e => {
    e.preventDefault();
    localStorage.setItem('vitallens_env', JSON.stringify({
      airQuality: document.getElementById('env-air')?.value || 'good',
      waterQuality: document.getElementById('env-water')?.value || 'filtered',
      location: document.getElementById('env-location')?.value || '',
      climate: document.getElementById('env-climate')?.value || 'temperate',
    }));
    showToast('✅ Environment data saved');
  });

  // ── Strava handlers ──
  setupStravaHandlers();
}

function setupStravaHandlers() {
  document.getElementById('strava-save-connect')?.addEventListener('click', () => {
    const clientId = document.getElementById('strava-client-id')?.value?.trim();
    const clientSecret = document.getElementById('strava-client-secret')?.value?.trim();
    if (!clientId || !clientSecret) { showToast('⚠️ Please enter both Client ID and Secret'); return; }
    saveStravaConfig({ clientId, clientSecret });
    try { window.location.href = getAuthorizationUrl(); } catch (err) { showToast('❌ ' + err.message); }
  });

  document.getElementById('strava-authorize')?.addEventListener('click', () => {
    try { window.location.href = getAuthorizationUrl(); } catch (err) { showToast('❌ ' + err.message); }
  });

  document.getElementById('strava-reset')?.addEventListener('click', () => {
    disconnectStrava();
    saveStravaConfig({ clientId: null, clientSecret: null });
    renderTabContent();
    showToast('🔄 Strava credentials cleared');
  });

  document.getElementById('strava-sync')?.addEventListener('click', async () => {
    const btn = document.getElementById('strava-sync');
    btn.disabled = true;
    btn.innerHTML = '<div class="spinner" style="width:16px;height:16px;border-width:2px;"></div> Syncing...';
    try {
      const activities = await syncActivities();
      showToast(`✅ Synced ${activities.length} activities from Strava`);
      renderTabContent();
    } catch (err) {
      showToast('❌ Sync failed: ' + err.message);
      btn.disabled = false;
    }
  });

  document.getElementById('strava-disconnect')?.addEventListener('click', () => {
    if (confirm('Disconnect Strava?')) { disconnectStrava(); renderTabContent(); showToast('🔌 Strava disconnected'); }
  });

  document.getElementById('strava-import-all')?.addEventListener('click', () => {
    const count = importAllActivities();
    showToast(`✅ Imported ${count} activities`);
    renderTabContent();
  });

  document.querySelectorAll('.strava-import-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const stravaId = parseInt(btn.dataset.stravaId);
      const cfg = getStravaConfig();
      const activity = cfg.activities?.find(a => a.stravaId === stravaId);
      if (activity) { importActivity(activity); showToast(`✅ Imported "${activity.name}"`); renderTabContent(); }
    });
  });
}

function showToast(msg) {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div'); t.className = 'toast'; t.innerHTML = `<span>${msg}</span>`;
  c.appendChild(t); setTimeout(() => { t.classList.add('removing'); setTimeout(() => t.remove(), 300); }, 3000);
}