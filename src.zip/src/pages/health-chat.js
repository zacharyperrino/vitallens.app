// AI Health Chat page — conversational copilot UI
import { store } from '../store.js';
import { icons } from '../icons.js';
import { HealthCopilot } from '../utils/health-copilot.js';

let copilot = null;
let messages = [];

export function renderHealthChat() {
    const content = document.getElementById('page-content');
    if (!copilot) copilot = new HealthCopilot();

    // Load persisted history or start fresh
    const saved = store.get('chatHistory') || [];
    if (messages.length === 0 && saved.length > 0) {
        messages = saved;
    }

    content.innerHTML = `
    <div class="chat-page">
      <div class="chat-header">
        <div class="chat-header-avatar">
          <span class="chat-ai-icon">✨</span>
        </div>
        <div class="chat-header-info">
          <h2>Health Copilot</h2>
          <span class="chat-status-dot"></span>
          <span class="chat-status-text">Online • Analyzing your data</span>
        </div>
        <button class="chat-clear-btn" id="chat-clear" title="Clear chat">
          ${icons.refresh || '🔄'}
        </button>
      </div>

      <div class="chat-messages" id="chat-messages">
        ${messages.length === 0 ? renderWelcome() : messages.map(renderMessage).join('')}
      </div>

      <div class="chat-suggestions" id="chat-suggestions">
        ${renderChips(messages.length === 0 ? ['How\'s my score?', 'Nutrition summary', 'Sleep analysis', 'Give me tips'] : [])}
      </div>

      <div class="chat-input-bar">
        <input type="text" class="chat-input" id="chat-input" placeholder="Ask about your health..." autocomplete="off" />
        <button class="chat-send-btn" id="chat-send">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
        </button>
      </div>
    </div>`;

    setupChatHandlers();
    scrollToBottom();
}

function renderWelcome() {
    const welcome = copilot.getWelcome();
    // Add welcome as first message
    messages.push({ role: 'assistant', text: welcome.text, chips: welcome.chips, timestamp: Date.now() });
    return renderMessage(messages[0]);
}

function renderMessage(msg) {
    const isUser = msg.role === 'user';
    const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    if (isUser) {
        return `
        <div class="chat-bubble chat-bubble-user animate-slide-in-right">
          <div class="chat-bubble-content">${escapeHtml(msg.text)}</div>
          <div class="chat-bubble-time">${time}</div>
        </div>`;
    }

    // Assistant message — parse markdown-like formatting
    let html = formatResponse(msg.text);

    // Stats cards
    let statsHtml = '';
    if (msg.stats && msg.stats.length > 0) {
        statsHtml = `<div class="chat-stats-row">${msg.stats.map(s =>
            `<div class="chat-stat-card chat-stat-${s.color || 'teal'}">
                <div class="chat-stat-value">${s.value}</div>
                <div class="chat-stat-label">${s.label}</div>
            </div>`
        ).join('')}</div>`;
    }

    return `
    <div class="chat-bubble chat-bubble-assistant animate-slide-in-left">
      <div class="chat-bubble-avatar">✨</div>
      <div class="chat-bubble-body">
        <div class="chat-bubble-content">${html}</div>
        ${statsHtml}
        <div class="chat-bubble-time">${time}</div>
      </div>
    </div>`;
}

function renderChips(chips) {
    if (!chips || chips.length === 0) return '';
    return chips.map(c =>
        `<button class="chat-chip" data-chip="${escapeHtml(c)}">${c}</button>`
    ).join('');
}

function renderTypingIndicator() {
    return `
    <div class="chat-bubble chat-bubble-assistant chat-typing" id="typing-indicator">
      <div class="chat-bubble-avatar">✨</div>
      <div class="chat-bubble-body">
        <div class="chat-typing-dots">
          <span></span><span></span><span></span>
        </div>
      </div>
    </div>`;
}

function formatResponse(text) {
    if (!text) return '';
    let html = text;
    // Headers
    html = html.replace(/^### (.+)$/gm, '<h4>$1</h4>');
    html = html.replace(/^## (.+)$/gm, '<h3 class="chat-section-title">$1</h3>');
    html = html.replace(/^# (.+)$/gm, '<div class="chat-big-stat">$1</div>');
    // Bold
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    // Tables
    html = html.replace(/\|(.+)\|\n\|[-|]+\|\n((?:\|.+\|\n?)+)/g, (_, header, rows) => {
        const headers = header.split('|').map(h => h.trim()).filter(h => h);
        const rowsArr = rows.trim().split('\n').map(r => r.split('|').map(c => c.trim()).filter(c => c));
        return `<table class="chat-table"><thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rowsArr.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    });
    // Blockquotes
    html = html.replace(/^> (.+)$/gm, '<div class="chat-callout">$1</div>');
    // Lists
    html = html.replace(/^• (.+)$/gm, '<div class="chat-list-item">• $1</div>');
    // Line breaks
    html = html.replace(/\n\n/g, '<br/><br/>');
    html = html.replace(/\n/g, '<br/>');
    return html;
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function scrollToBottom() {
    requestAnimationFrame(() => {
        const container = document.getElementById('chat-messages');
        if (container) container.scrollTop = container.scrollHeight;
    });
}

function saveHistory() {
    // Keep last 50 messages
    const toSave = messages.slice(-50);
    store.set('chatHistory', toSave);
}

function sendMessage(text) {
    if (!text || !text.trim()) return;
    const userMsg = { role: 'user', text: text.trim(), timestamp: Date.now() };
    messages.push(userMsg);

    // Render user message
    const container = document.getElementById('chat-messages');
    if (!container) return;
    container.insertAdjacentHTML('beforeend', renderMessage(userMsg));
    scrollToBottom();

    // Show typing indicator
    container.insertAdjacentHTML('beforeend', renderTypingIndicator());
    scrollToBottom();

    // Clear suggestions while thinking
    const sugContainer = document.getElementById('chat-suggestions');
    if (sugContainer) sugContainer.innerHTML = '';

    // Simulate "thinking" delay for natural feel
    const delay = 400 + Math.random() * 800;
    setTimeout(() => {
        // Remove typing indicator
        const typing = document.getElementById('typing-indicator');
        if (typing) typing.remove();

        // Get response from copilot
        const response = copilot.chat(text.trim());
        const assistantMsg = {
            role: 'assistant',
            text: response.text,
            stats: response.stats,
            chips: response.chips,
            timestamp: Date.now(),
        };
        messages.push(assistantMsg);

        // Render assistant response
        container.insertAdjacentHTML('beforeend', renderMessage(assistantMsg));
        scrollToBottom();

        // Update suggestion chips
        if (sugContainer && response.chips) {
            sugContainer.innerHTML = renderChips(response.chips);
            attachChipHandlers();
        }

        saveHistory();
    }, delay);

    // Clear input
    const input = document.getElementById('chat-input');
    if (input) input.value = '';
}

function attachChipHandlers() {
    document.querySelectorAll('.chat-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            sendMessage(chip.dataset.chip);
        });
    });
}

function setupChatHandlers() {
    // Send button
    const sendBtn = document.getElementById('chat-send');
    const input = document.getElementById('chat-input');

    sendBtn?.addEventListener('click', () => sendMessage(input?.value));

    // Enter key
    input?.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage(input.value);
        }
    });

    // Clear history
    document.getElementById('chat-clear')?.addEventListener('click', () => {
        messages = [];
        copilot.clearSession();
        store.set('chatHistory', []);
        renderHealthChat();
    });

    // Suggestion chips
    attachChipHandlers();

    // Auto-focus input
    input?.focus();
}
