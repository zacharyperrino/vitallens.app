// Food Scanner Page — Meal Scan & Product Scan Modes
import { icons } from '../icons.js';
import { getRandomFoodCombo } from '../utils/food-analyzer.js';
import { createDonutChart } from '../utils/charts.js';
import { lookupBarcode, parseNutritionLabel, getHealthScore, getMealAnalysis } from '../services/foodScanApi.js';
import { initCamera, stopCamera, startBarcodeScanner, getScoreColor } from '../utils/product-scanner.js';
import { meals, productScans, dailyNutrition } from '../lib/db.js';

let currentMode = 'meal';
let cameraStream = null;
let stopScanning = null;

function renderComboCard(combo) {
  const isGood = combo.type === 'good';
  return `
    <div class="card ${isGood ? 'combo-good' : 'combo-bad'}" style="margin-bottom:var(--space-3);">
      <div style="display:flex;align-items:center;gap:var(--space-2);margin-bottom:var(--space-2);">
        <span style="font-size:18px;">${isGood ? '✅' : '⚠️'}</span>
        <h4 style="font-size:var(--text-sm);">${combo.title}</h4>
        <span class="badge ${isGood ? 'badge-green' : 'badge-coral'}" style="margin-left:auto;">${isGood ? 'Optimal' : 'Avoid'}</span>
      </div>
      <p style="font-size:var(--text-xs);color:var(--text-secondary);line-height:1.5;">${combo.explanation}</p>
    </div>
  `;
}

export async function renderFoodScanner() {
  const content = document.getElementById('page-content');

  // Load data from Supabase
  let recentMeals = [];
  let recentScans = [];
  let todayNutrition = { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 };

  try { recentMeals = await meals.getRecent(5); } catch (e) { console.warn('Could not load meals:', e.message); }
  try { recentScans = await productScans.getRecent(5); } catch (e) { console.warn('Could not load scans:', e.message); }
  try { todayNutrition = await dailyNutrition.get(); } catch (e) { console.warn('Could not load nutrition:', e.message); }

  content.innerHTML = `
    <div class="food-scanner stagger-children">
      <div class="page-header">
        <h1>🍽️ Food Scanner</h1>
        <p>Scan meals or product barcodes for health insights</p>
      </div>

      ${todayNutrition.calories > 0 ? `
      <div class="card" style="margin-bottom:var(--space-4);">
        <h4 style="margin-bottom:var(--space-3);">Today's Nutrition</h4>
        <div style="display:flex;justify-content:space-between;text-align:center;">
          <div>
            <div style="font-family:var(--font-heading);font-size:var(--text-xl);font-weight:var(--weight-bold);color:var(--accent-teal);">${Math.round(todayNutrition.calories)}</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">calories</div>
          </div>
          <div>
            <div style="font-family:var(--font-heading);font-size:var(--text-xl);font-weight:var(--weight-bold);color:var(--accent-blue);">${Math.round(todayNutrition.protein)}g</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">protein</div>
          </div>
          <div>
            <div style="font-family:var(--font-heading);font-size:var(--text-xl);font-weight:var(--weight-bold);color:var(--accent-amber);">${Math.round(todayNutrition.carbs)}g</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">carbs</div>
          </div>
          <div>
            <div style="font-family:var(--font-heading);font-size:var(--text-xl);font-weight:var(--weight-bold);color:var(--accent-coral);">${Math.round(todayNutrition.fat)}g</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">fat</div>
          </div>
        </div>
      </div>` : ''}

      <div class="scan-mode-toggle">
        <button class="mode-btn ${currentMode === 'meal' ? 'mode-btn-active' : ''}" id="mode-meal">
          ${icons.camera} Meal Scan
        </button>
        <button class="mode-btn ${currentMode === 'product' ? 'mode-btn-active' : ''}" id="mode-product">
          ${icons.barcode} Product Scan
        </button>
      </div>

      <!-- Meal Scan View -->
      <div id="meal-scan-view" style="${currentMode !== 'meal' ? 'display:none;' : ''}">
        <div class="card" style="padding:0;overflow:hidden;margin-bottom:var(--space-5);" id="food-upload-card">
          <div class="upload-zone" id="food-upload-zone">
            <input type="file" accept="image/*" capture="environment" id="food-file-input">
            <div style="color:var(--text-tertiary);">${icons.camera}</div>
            <p><span class="upload-btn-text">Take Photo</span> or drag &amp; drop</p>
            <p style="font-size:var(--text-xs);">Supports JPG, PNG up to 10MB</p>
          </div>
        </div>
        <div id="food-results" class="hidden">
          <div class="portion-selector">
            <label>Portion Size</label>
            <select id="portion-select">
              <option value="small">Small</option>
              <option value="medium" selected>Medium</option>
              <option value="large">Large</option>
            </select>
          </div>
        </div>
        <div class="section-heading">
          <h3>Food Pairing Insight</h3>
          <span class="see-all" id="shuffle-combo" style="cursor:pointer;">Shuffle</span>
        </div>
        <div id="food-combo-card">
          <div id="food-combo-placeholder"></div>
        </div>
        <div class="section-heading" style="margin-top:var(--space-6);">
          <h3>Recent Meals</h3>
          <span class="badge badge-teal">${recentMeals.length} logged</span>
        </div>
        <div id="meal-history" style="display:flex;flex-direction:column;gap:var(--space-3);">
          ${recentMeals.length > 0 ? recentMeals.map(renderMealCard).join('') : renderEmptyMeals()}
        </div>
      </div>

      <!-- Product Scan View -->
      <div id="product-scan-view" style="${currentMode !== 'product' ? 'display:none;' : ''}">
        <div class="card barcode-scanner-card" id="barcode-scanner-card">
          <div class="barcode-viewfinder">
            <video id="barcode-video" autoplay playsinline muted></video>
            <div class="barcode-overlay">
              <div class="barcode-scan-region">
                <div class="barcode-corner tl"></div>
                <div class="barcode-corner tr"></div>
                <div class="barcode-corner bl"></div>
                <div class="barcode-corner br"></div>
              </div>
              <p class="barcode-hint">Align barcode within the frame</p>
            </div>
          </div>
          <div class="barcode-actions">
            <button class="btn btn-sm btn-outline" id="btn-start-camera">
              ${icons.camera} Start Camera
            </button>
            <button class="btn btn-sm btn-outline" id="btn-capture-label">
              📷 Capture Label
            </button>
          </div>
        </div>

        <div class="card" style="margin-top:var(--space-3);">
          <h4 style="margin-bottom:var(--space-2);font-size:var(--text-sm);">Manual Barcode Entry</h4>
          <div style="display:flex;gap:var(--space-2);">
            <input type="text" id="manual-barcode" placeholder="e.g. 3017620422003"
              style="flex:1;font-size:var(--text-sm);padding:var(--space-2) var(--space-3);background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);color:var(--text-primary);">
            <button class="btn btn-primary btn-sm" id="btn-manual-lookup">
              ${icons.scan} Look Up
            </button>
          </div>
        </div>

        <input type="file" accept="image/*" capture="environment" id="ocr-file-input" style="display:none;">

        <div id="product-scan-loading" class="hidden">
          <div class="card" style="text-align:center;padding:var(--space-6);">
            <div class="spinner" style="margin:0 auto var(--space-3);"></div>
            <p style="font-size:var(--text-sm);color:var(--text-secondary);" id="scan-status-text">Looking up product...</p>
          </div>
        </div>

        <div id="product-scan-error" class="hidden">
          <div class="card" style="text-align:center;padding:var(--space-6);border-left:3px solid var(--accent-coral);">
            <div style="font-size:32px;margin-bottom:var(--space-2);">⚠️</div>
            <p style="font-size:var(--text-sm);color:var(--text-secondary);" id="scan-error-text">An error occurred</p>
            <button class="btn btn-sm btn-outline" id="btn-try-again" style="margin-top:var(--space-3);">Try Again</button>
          </div>
        </div>

        <div class="section-heading" style="margin-top:var(--space-5);">
          <h3>Recent Scans</h3>
          <span class="badge badge-teal">${recentScans.length} scanned</span>
        </div>
        <div id="product-scan-history" style="display:flex;flex-direction:column;gap:var(--space-3);">
          ${recentScans.length > 0 ? recentScans.map(renderProductScanCard).join('') : renderEmptyScans()}
        </div>

        <p style="font-size:10px;color:var(--text-tertiary);text-align:center;margin-top:var(--space-4);line-height:1.4;">
          ⚠️ Scores are for informational purposes only. Not medical advice.
        </p>
      </div>
    </div>
  `;

  setupModeToggle();
  document.getElementById('food-combo-placeholder').innerHTML = renderComboCard(getRandomFoodCombo());
  setupFoodUpload();
  setupProductScan();

  document.getElementById('shuffle-combo')?.addEventListener('click', () => {
    document.getElementById('food-combo-placeholder').innerHTML = renderComboCard(getRandomFoodCombo());
  });
}

// ─── Mode Toggle ─────────────────────────────────────────────

function setupModeToggle() {
  document.getElementById('mode-meal')?.addEventListener('click', () => switchMode('meal'));
  document.getElementById('mode-product')?.addEventListener('click', () => switchMode('product'));
}

function switchMode(mode) {
  currentMode = mode;
  if (mode !== 'product' && cameraStream) {
    stopCamera(cameraStream);
    cameraStream = null;
    if (stopScanning) { stopScanning(); stopScanning = null; }
  }
  document.getElementById('meal-scan-view').style.display = mode === 'meal' ? '' : 'none';
  document.getElementById('product-scan-view').style.display = mode === 'product' ? '' : 'none';
  document.getElementById('mode-meal').className = `mode-btn ${mode === 'meal' ? 'mode-btn-active' : ''}`;
  document.getElementById('mode-product').className = `mode-btn ${mode === 'product' ? 'mode-btn-active' : ''}`;
}

// ─── Meal Upload ──────────────────────────────────────────────

function setupFoodUpload() {
  const zone = document.getElementById('food-upload-zone');
  const input = document.getElementById('food-file-input');

  ['dragenter', 'dragover'].forEach(e => {
    zone?.addEventListener(e, (ev) => { ev.preventDefault(); zone.classList.add('dragover'); });
  });
  ['dragleave', 'drop'].forEach(e => {
    zone?.addEventListener(e, (ev) => { ev.preventDefault(); zone.classList.remove('dragover'); });
  });
  zone?.addEventListener('drop', (e) => {
    const file = e.dataTransfer?.files[0];
    if (file) processFood(file);
  });
  input?.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (file) processFood(file);
  });
}

async function processFood(file) {
  const card = document.getElementById('food-upload-card');
  const resultsDiv = document.getElementById('food-results');

  card.innerHTML = `
    <div class="scanner-preview">
      <img id="food-preview-img" alt="Food preview" style="width:100%;height:100%;object-fit:cover;">
      <div class="scanner-line"></div>
      <div style="position:absolute;bottom:var(--space-3);left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:var(--space-2);background:rgba(0,0,0,0.6);padding:var(--space-2) var(--space-4);border-radius:var(--radius-full);">
        <div class="spinner" style="width:16px;height:16px;border-width:2px;"></div>
        <span style="font-size:var(--text-sm);color:white;">Analyzing meal...</span>
      </div>
    </div>
  `;

  const reader = new FileReader();
  reader.onload = (e) => {
    const img = document.getElementById('food-preview-img');
    if (img) img.src = e.target.result;
  };
  reader.readAsDataURL(file);

  try {
    const selectedPortion = document.getElementById('portion-select')?.value || 'medium';
    const result = await getMealAnalysis(file, selectedPortion);

    // Meal saved when user confirms portions below

    card.innerHTML = `
      <div class="scanner-preview" style="aspect-ratio:auto;padding:0;position:relative;">
        <img id="food-preview-img-done" alt="Scanned food" style="width:100%;height:200px;object-fit:cover;display:block;">
        <canvas id="food-box-overlay" style="position:absolute;top:0;left:0;width:100%;height:200px;pointer-events:none;"></canvas>
        <div style="position:absolute;top:var(--space-3);right:var(--space-3);">
          <div class="badge badge-green">${icons.check} Analyzed</div>
        </div>
      </div>
    `;

    const imgDone = document.getElementById('food-preview-img-done');
    if (imgDone) imgDone.src = reader.result;
    imgDone.onload = () => { drawDetectionOverlay(imgDone, result.foods || []); };

    resultsDiv.classList.remove('hidden');
    resultsDiv.innerHTML = renderFoodResults(result);
    setupPortionSliders(result);
    resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });

    const correctionSelect = document.getElementById('food-correction');
    if (correctionSelect) {
      (result.detections || []).forEach(pred => {
        const option = document.createElement('option');
        option.value = pred.label;
        option.textContent = pred.label;
        correctionSelect.appendChild(option);
      });
      correctionSelect.addEventListener('change', (e) => {
        if (e.target.value) logFoodCorrection(e.target.value, result);
      });
    }

    showToast('✅ Meal analyzed! Adjust portions if needed.');

  } catch (err) {
    console.error('[MealScan] Processing error:', err);
    card.innerHTML = `
      <div class="upload-zone" id="food-upload-zone" style="border-color:var(--accent-coral);">
        <div style="color:var(--accent-coral);font-size:32px;margin-bottom:var(--space-2);">⚠️</div>
        <p style="color:var(--text-primary);">Failed to analyze meal</p>
        <p style="font-size:var(--text-xs);color:var(--text-secondary);margin-bottom:var(--space-3);">${err.message}</p>
        <button class="btn btn-sm btn-outline" onclick="location.reload()">Try Again</button>
      </div>
    `;
    showToast('❌ Analysis failed. Check server connection.');
  }
}

// ─── Product Scan ─────────────────────────────────────────────

function setupProductScan() {
  document.getElementById('btn-start-camera')?.addEventListener('click', async () => {
    const video = document.getElementById('barcode-video');
    try {
      cameraStream = await initCamera(video);
      stopScanning = await startBarcodeScanner(video, handleBarcodeDetected);
      document.getElementById('btn-start-camera').textContent = '📹 Scanning...';
      document.getElementById('btn-start-camera').disabled = true;
    } catch (err) {
      showProductError(err.message);
    }
  });

  document.getElementById('btn-manual-lookup')?.addEventListener('click', () => {
    const input = document.getElementById('manual-barcode');
    const barcode = input?.value?.trim();
    if (barcode && barcode.length >= 8) handleBarcodeDetected(barcode);
  });

  document.getElementById('manual-barcode')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('btn-manual-lookup')?.click();
  });

  document.getElementById('btn-capture-label')?.addEventListener('click', () => {
    document.getElementById('ocr-file-input')?.click();
  });

  document.getElementById('ocr-file-input')?.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (file) await handleOcrCapture(file);
  });

  document.getElementById('btn-try-again')?.addEventListener('click', () => {
    document.getElementById('product-scan-error').classList.add('hidden');
  });
}

async function handleBarcodeDetected(barcode) {
  if (cameraStream) { stopCamera(cameraStream); cameraStream = null; }
  if (stopScanning) { stopScanning(); stopScanning = null; }

  showProductLoading(`Looking up barcode: ${barcode}...`);

  try {
    const result = await lookupBarcode(barcode);

    try {
      await productScans.log({
        barcode: result.product.barcode,
        name: result.product.name,
        brand: result.product.brand,
        score: result.healthScore.score,
        rating: result.healthScore.rating,
        nutrition: result.product.nutrition,
        additives: result.additives,
        scanType: 'barcode',
      });
    } catch (dbErr) {
      console.error('[ProductScan] Failed to save to Supabase:', dbErr.message);
    }

    window._lastProductScan = result;
    location.hash = '#/product-results';
  } catch (err) {
    showProductError(err.message || 'Product not found.');
  }
}

async function handleOcrCapture(file) {
  showProductLoading('Analyzing nutrition label...');

  try {
    const ocrResult = await parseNutritionLabel(file);
    const scoreResult = await getHealthScore(ocrResult.nutrition, []);

    try {
      await productScans.log({
        barcode: 'OCR-SCAN',
        name: 'Scanned Product',
        score: scoreResult.score,
        rating: scoreResult.rating,
        nutrition: ocrResult.nutrition,
        scanType: 'ocr',
      });
    } catch (dbErr) {
      console.error('[OCR] Failed to save to Supabase:', dbErr.message);
    }

    window._lastProductScan = {
      product: { barcode: 'OCR-SCAN', name: 'Scanned Product', brand: '', ingredients: '', nutrition: ocrResult.nutrition, nutriscore: null, nova_group: null, image_url: null },
      healthScore: scoreResult,
      additives: { analyzed: [], summary: { total: 0, high: 0, moderate: 0, low: 0 } },
    };

    location.hash = '#/product-results';
  } catch (err) {
    showProductError('Failed to parse label. Ensure it is clearly visible.');
  }
}

function showProductLoading(msg) {
  document.getElementById('product-scan-loading')?.classList.remove('hidden');
  document.getElementById('product-scan-error')?.classList.add('hidden');
  const el = document.getElementById('scan-status-text');
  if (el) el.textContent = msg;
}

function showProductError(msg) {
  document.getElementById('product-scan-loading')?.classList.add('hidden');
  document.getElementById('product-scan-error')?.classList.remove('hidden');
  const el = document.getElementById('scan-error-text');
  if (el) el.textContent = msg;
}

// ─── Food Results with Portion Sliders ───────────────────────

function renderFoodResults(result) {
  const { food, foods = [], combinations, healthRating, digestibilityScore } = result;
  const totalMacro = Math.round((food.protein || 0) + (food.carbs || 0) + (food.fat || 0));
  const proteinPct = totalMacro ? Math.round(((food.protein || 0) / totalMacro) * 100) : 0;
  const carbsPct = totalMacro ? Math.round(((food.carbs || 0) / totalMacro) * 100) : 0;
  const fatPct = totalMacro ? 100 - proteinPct - carbsPct : 0;

  return `
    <div class="stagger-children" style="display:flex;flex-direction:column;gap:var(--space-4);">

      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-3);">
          <div>
            <h3 style="font-size:var(--text-lg);margin-bottom:var(--space-1);">${food.name}</h3>
            <span class="badge badge-teal">Health Rating: ${Math.round(healthRating || 0)}/100</span>
          </div>
          <div style="text-align:center;">
            <div id="total-calories-display" style="font-family:var(--font-heading);font-size:var(--text-3xl);font-weight:var(--weight-extrabold);color:var(--accent-teal);">${Math.round(food.calories || 0)}</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">calories</div>
          </div>
        </div>
      </div>

      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-3);">
          <h4>Detected Foods</h4>
          <span style="font-size:var(--text-xs);color:var(--text-tertiary);">Drag to adjust portions</span>
        </div>
        <div id="portion-items" style="display:flex;flex-direction:column;gap:var(--space-4);">
          ${(foods.length ? foods : [{ name: food.name, grams: 150, confidence: 1, nutrients: { calories: food.calories, protein: food.protein, carbs: food.carbs, fat: food.fat, fiber: food.fiber } }]).map((item, i) => `
            <div class="portion-item" data-index="${i}"
              data-base-grams="${item.grams || 150}"
              data-calories-per-g="${((item.nutrients?.calories || 0) / (item.grams || 150)).toFixed(4)}"
              data-protein-per-g="${((item.nutrients?.protein || 0) / (item.grams || 150)).toFixed(4)}"
              data-carbs-per-g="${((item.nutrients?.carbs || 0) / (item.grams || 150)).toFixed(4)}"
              data-fat-per-g="${((item.nutrients?.fat || 0) / (item.grams || 150)).toFixed(4)}"
              data-fiber-per-g="${((item.nutrients?.fiber || 0) / (item.grams || 150)).toFixed(4)}">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-2);">
                <div>
                  <div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${item.name}</div>
                  <div style="font-size:var(--text-xs);color:var(--text-tertiary);">
                    ${item.confidence ? `${(item.confidence * 100).toFixed(0)}% confidence` : ''}
                  </div>
                </div>
                <div style="text-align:right;">
                  <span id="grams-display-${i}" style="font-family:var(--font-heading);font-size:var(--text-lg);font-weight:var(--weight-bold);color:var(--accent-teal);">${item.grams || 150}g</span>
                  <div id="kcal-display-${i}" style="font-size:var(--text-xs);color:var(--text-tertiary);">${Math.round(item.nutrients?.calories || 0)} kcal</div>
                </div>
              </div>
              <input type="range" id="portion-slider-${i}" min="20" max="600" step="5" value="${item.grams || 150}"
                style="width:100%;accent-color:var(--accent-teal);cursor:pointer;" />
              <div style="display:flex;justify-content:space-between;margin-top:var(--space-1);">
                <span style="font-size:var(--text-xs);color:var(--text-tertiary);">20g</span>
                <span style="font-size:var(--text-xs);color:var(--text-tertiary);">Taste · Small · Medium · Large · XL</span>
                <span style="font-size:var(--text-xs);color:var(--text-tertiary);">600g</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <div class="card">
        <h4 style="margin-bottom:var(--space-4);">Macronutrients</h4>
        <div style="display:flex;align-items:center;gap:var(--space-5);">
          <div class="chart-container" style="flex-shrink:0;">
            ${createDonutChart([
    { percent: proteinPct, color: 'var(--accent-blue)' },
    { percent: carbsPct, color: 'var(--accent-amber)' },
    { percent: fatPct, color: 'var(--accent-coral)' },
  ], 100, 10)}
            <div class="chart-center-label">
              <div class="value" id="total-macro-display" style="font-size:var(--text-md);">${totalMacro}g</div>
              <div class="label">total</div>
            </div>
          </div>
          <div style="flex:1;">
            <div class="nutrient-row">
              <div class="nutrient-info"><div class="nutrient-dot" style="background:var(--accent-blue);"></div><span class="nutrient-name">Protein</span></div>
              <span class="nutrient-value" id="protein-display">${Math.round(food.protein || 0)}g (${proteinPct}%)</span>
            </div>
            <div class="nutrient-row">
              <div class="nutrient-info"><div class="nutrient-dot" style="background:var(--accent-amber);"></div><span class="nutrient-name">Carbs</span></div>
              <span class="nutrient-value" id="carbs-display">${Math.round(food.carbs || 0)}g (${carbsPct}%)</span>
            </div>
            <div class="nutrient-row">
              <div class="nutrient-info"><div class="nutrient-dot" style="background:var(--accent-coral);"></div><span class="nutrient-name">Fat</span></div>
              <span class="nutrient-value" id="fat-display">${Math.round(food.fat || 0)}g (${fatPct}%)</span>
            </div>
            ${food.fiber ? `
            <div class="nutrient-row">
              <div class="nutrient-info"><div class="nutrient-dot" style="background:var(--accent-green);"></div><span class="nutrient-name">Fiber</span></div>
              <span class="nutrient-value" id="fiber-display">${Math.round(food.fiber || 0)}g</span>
            </div>` : ''}
          </div>
        </div>
      </div>

      ${food.micronutrients && food.micronutrients.length > 0 ? `
      <div class="card">
        <h4 style="margin-bottom:var(--space-3);">Micronutrients</h4>
        ${food.micronutrients.map(m => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:var(--space-2) 0;">
            <span style="font-size:var(--text-sm);color:var(--text-secondary);">${m.name}</span>
            <div style="display:flex;align-items:center;gap:var(--space-3);">
              <span style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${m.amount}</span>
              <div style="width:60px;">
                <div class="progress-bar" style="height:4px;">
                  <div class="progress-fill" style="width:${Math.min(100, m.rda)}%;background:${m.rda >= 80 ? 'var(--accent-green)' : m.rda >= 40 ? 'var(--accent-amber)' : 'var(--accent-coral)'}"></div>
                </div>
              </div>
              <span style="font-size:var(--text-xs);color:var(--text-tertiary);min-width:32px;text-align:right;">${m.rda}%</span>
            </div>
          </div>
        `).join('')}
        <p style="font-size:var(--text-xs);color:var(--text-tertiary);margin-top:var(--space-3);text-align:center;">% of Recommended Daily Allowance</p>
      </div>` : ''}

      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>
            <h4 style="margin-bottom:var(--space-1);">Digestibility Score</h4>
            <p style="font-size:var(--text-xs);">How easily your body can process this meal</p>
          </div>
          <div style="font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:var(--weight-bold);color:${(digestibilityScore || 0) >= 80 ? 'var(--accent-green)' : 'var(--accent-amber)'};">${Math.round(digestibilityScore || 0)}%</div>
        </div>
      </div>

      <div class="section-heading"><h3>Food Combination Analysis</h3></div>
      ${(combinations || []).map(c => renderComboCard(c)).join('')}

      <button id="confirm-save-btn" class="btn btn-primary btn-block" style="margin-top:var(--space-2);">
        ✅ Confirm & Save to Health Log
      </button>
      <p style="font-size:var(--text-xs);color:var(--text-tertiary);text-align:center;margin-top:calc(-1 * var(--space-2));">
        Adjust portions above before saving
      </p>

      <div class="card">
        <h4 style="margin-bottom:var(--space-2);">Not correct?</h4>
        <select id="food-correction" style="width:100%;padding:var(--space-2);border-radius:var(--radius-md);">
          <option value="">Choose correct food</option>
        </select>
      </div>
    </div>
  `;
}

function setupPortionSliders(result) {
  const items = document.querySelectorAll('.portion-item');

  function recalculateTotals() {
    let totalCalories = 0, totalProtein = 0, totalCarbs = 0, totalFat = 0, totalFiber = 0;

    items.forEach((item, i) => {
      const slider = document.getElementById(`portion-slider-${i}`);
      const grams = parseFloat(slider.value);
      const calPerG = parseFloat(item.dataset.caloriesPerG);
      const protPerG = parseFloat(item.dataset.proteinPerG);
      const carbsPerG = parseFloat(item.dataset.carbsPerG);
      const fatPerG = parseFloat(item.dataset.fatPerG);
      const fiberPerG = parseFloat(item.dataset.fiberPerG);

      const kcal = Math.round(calPerG * grams);
      const gramsDisplay = document.getElementById(`grams-display-${i}`);
      const kcalDisplay = document.getElementById(`kcal-display-${i}`);
      if (gramsDisplay) gramsDisplay.textContent = `${grams}g`;
      if (kcalDisplay) kcalDisplay.textContent = `${kcal} kcal`;

      totalCalories += calPerG * grams;
      totalProtein += protPerG * grams;
      totalCarbs += carbsPerG * grams;
      totalFat += fatPerG * grams;
      totalFiber += fiberPerG * grams;
    });

    totalCalories = Math.round(totalCalories);
    totalProtein = Math.round(totalProtein);
    totalCarbs = Math.round(totalCarbs);
    totalFat = Math.round(totalFat);
    totalFiber = Math.round(totalFiber);
    const totalMacro = totalProtein + totalCarbs + totalFat;
    const proteinPct = totalMacro ? Math.round((totalProtein / totalMacro) * 100) : 0;
    const carbsPct = totalMacro ? Math.round((totalCarbs / totalMacro) * 100) : 0;
    const fatPct = totalMacro ? 100 - proteinPct - carbsPct : 0;

    const calDisplay = document.getElementById('total-calories-display');
    if (calDisplay) calDisplay.textContent = totalCalories;
    const macroDisplay = document.getElementById('total-macro-display');
    if (macroDisplay) macroDisplay.textContent = `${totalMacro}g`;
    const proteinDisplay = document.getElementById('protein-display');
    if (proteinDisplay) proteinDisplay.textContent = `${totalProtein}g (${proteinPct}%)`;
    const carbsDisplay = document.getElementById('carbs-display');
    if (carbsDisplay) carbsDisplay.textContent = `${totalCarbs}g (${carbsPct}%)`;
    const fatDisplay = document.getElementById('fat-display');
    if (fatDisplay) fatDisplay.textContent = `${totalFat}g (${fatPct}%)`;
    const fiberDisplay = document.getElementById('fiber-display');
    if (fiberDisplay) fiberDisplay.textContent = `${totalFiber}g`;

    return { totalCalories, totalProtein, totalCarbs, totalFat, totalFiber };
  }

  items.forEach((item, i) => {
    const slider = document.getElementById(`portion-slider-${i}`);
    if (slider) slider.addEventListener('input', recalculateTotals);
  });

  const confirmBtn = document.getElementById('confirm-save-btn');
  if (confirmBtn) {
    confirmBtn.addEventListener('click', async () => {
      confirmBtn.disabled = true;
      confirmBtn.innerHTML = '<div class="spinner" style="width:16px;height:16px;border-width:2px;display:inline-block;margin-right:8px;"></div>Saving...';

      const totals = recalculateTotals();
      const adjustedFoods = Array.from(items).map((item, i) => {
        const slider = document.getElementById(`portion-slider-${i}`);
        const grams = parseFloat(slider.value);
        const origFood = result.foods[i] || {};
        return { ...origFood, grams };
      });

      try {
        await meals.log({
          name: result.food?.name || 'Scanned meal',
          calories: totals.totalCalories,
          protein: totals.totalProtein,
          carbs: totals.totalCarbs,
          fat: totals.totalFat,
          fiber: totals.totalFiber,
          confidence: result.foods?.[0]?.confidence || null,
          foods: adjustedFoods,
          healthRating: result.healthRating || null,
          digestibilityScore: result.digestibilityScore || null,
        });

        confirmBtn.innerHTML = '✅ Saved to Health Log!';
        confirmBtn.style.background = 'var(--accent-green)';
        showToast('✅ Meal saved with your adjusted portions!');
      } catch (err) {
        console.error('[FoodScanner] Save failed:', err.message);
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = '✅ Confirm & Save to Health Log';
        showToast('❌ Save failed — check connection.');
      }
    });
  }
}

// ─── Render helpers ───────────────────────────────────────────

function renderMealCard(meal) {
  const time = meal.logged_at
    ? new Date(meal.logged_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : meal.timestamp
      ? new Date(meal.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : '';
  return `
    <div class="card card-sm">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="display:flex;align-items:center;gap:var(--space-3);">
          <div style="width:36px;height:36px;border-radius:var(--radius-md);background:var(--accent-teal-dim);display:flex;align-items:center;justify-content:center;font-size:18px;">🍽️</div>
          <div>
            <div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${meal.name}</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${time} • P:${Math.round(meal.protein || 0)}g C:${Math.round(meal.carbs || 0)}g F:${Math.round(meal.fat || 0)}g</div>
          </div>
        </div>
        <div style="font-family:var(--font-heading);font-weight:var(--weight-bold);color:var(--accent-teal);">${Math.round(meal.calories || 0)}</div>
      </div>
    </div>
  `;
}

function renderEmptyMeals() {
  return `
    <div class="card" style="text-align:center;padding:var(--space-8);">
      <div style="font-size:40px;margin-bottom:var(--space-3);">🍽️</div>
      <h4 style="margin-bottom:var(--space-2);">No meals logged yet</h4>
      <p style="font-size:var(--text-sm);">Scan your first meal to start tracking nutrition</p>
    </div>
  `;
}

function renderProductScanCard(scan) {
  const score = scan.health_score ?? scan.score;
  const color = getScoreColor(score);
  return `
    <div class="card card-sm">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div style="display:flex;align-items:center;gap:var(--space-3);">
          <div style="width:36px;height:36px;border-radius:var(--radius-md);background:${color}22;display:flex;align-items:center;justify-content:center;font-size:18px;">🏷️</div>
          <div>
            <div style="font-size:var(--text-sm);font-weight:var(--weight-semibold);">${scan.name}</div>
            <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${scan.brand || scan.barcode}</div>
          </div>
        </div>
        <div style="text-align:center;">
          <div style="font-family:var(--font-heading);font-weight:var(--weight-bold);color:${color};font-size:var(--text-lg);">${score}</div>
          <div style="font-size:10px;color:var(--text-tertiary);">${scan.rating}</div>
        </div>
      </div>
    </div>
  `;
}

function renderEmptyScans() {
  return `
    <div class="card" style="text-align:center;padding:var(--space-6);">
      <div style="font-size:36px;margin-bottom:var(--space-2);">🏷️</div>
      <h4 style="margin-bottom:var(--space-1);">No products scanned</h4>
      <p style="font-size:var(--text-sm);color:var(--text-secondary);">Scan a barcode or nutrition label to see results</p>
    </div>
  `;
}

function drawDetectionOverlay(imgEl, foods) {
  const canvas = document.getElementById('food-box-overlay');
  if (!canvas || !imgEl || !foods?.length) return;
  const rect = imgEl.getBoundingClientRect();
  canvas.width = rect.width;
  canvas.height = rect.height;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.lineWidth = 2;
  ctx.font = '12px sans-serif';
  foods.forEach(item => {
    const box = item.box;
    if (!box) return;
    const x = box[0] * canvas.width;
    const y = box[1] * canvas.height;
    const w = (box[2] - box[0]) * canvas.width;
    const h = (box[3] - box[1]) * canvas.height;
    ctx.strokeStyle = '#00E5FF';
    ctx.strokeRect(x, y, w, h);
    const label = `${item.name} ${item.grams}g`;
    ctx.fillStyle = '#00E5FF';
    ctx.fillRect(x, y - 16, ctx.measureText(label).width + 10, 16);
    ctx.fillStyle = '#001018';
    ctx.fillText(label, x + 5, y - 4);
  });
}

function showToast(message) {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => { toast.classList.add('removing'); setTimeout(() => toast.remove(), 300); }, 3000);
}

function logFoodCorrection(correctedFood, result) {
  const feedback = {
    timestamp: new Date().toISOString(),
    predictions: result.detections || [],
    detectedFoods: result.foods || [],
    correctedFood,
    portion: document.getElementById('portion-select')?.value || 'medium',
  };
  console.log('Food correction logged:', feedback);
  localStorage.setItem('food_correction_' + Date.now(), JSON.stringify(feedback));
}

function saveHistory() {
  // Chat history persisted via db.js
}