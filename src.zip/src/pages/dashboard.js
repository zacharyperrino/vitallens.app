// Dashboard / Home page
import { store } from '../store.js';
import { icons } from '../icons.js';
import { createRingProgress, createSparkline, createLineChart } from '../utils/charts.js';
import { computeHealthScore, getHealthInsights } from '../utils/health-score.js';
import { isOuraConnected } from '../utils/oura.js';

export function renderDashboard() {
  const content = document.getElementById('page-content');
  const data = store.getAll();
  const health = computeHealthScore(data);
  const insights = getHealthInsights(data);
  const ouraConnected = isOuraConnected();
  const latestReadiness = data.oura?.readiness?.[0]?.score || '--';
  const latestSleep = data.oura?.sleep?.[0]?.score || '--';

  const greeting = getGreeting();
  const name = data.profile?.name || 'Explorer';

  content.innerHTML = `
    <div class="dashboard stagger-children">
      <!-- Header -->
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start;">
        <div>
          <p style="font-size:var(--text-sm);color:var(--text-tertiary);margin-bottom:var(--space-1);">${greeting}</p>
          <h1 style="font-size:var(--text-2xl);">
            <span class="text-gradient">${name}</span>
          </h1>
        </div>
        <div onclick="location.hash='#/profile'" style="cursor:pointer;width:42px;height:42px;border-radius:var(--radius-full);background:var(--bg-glass-heavy);display:flex;align-items:center;justify-content:center;font-size:20px;border:1px solid var(--border-subtle);">
          ${data.profile?.avatar || '🧬'}
        </div>
      </div>

      <!-- Health Score Ring -->
      <div class="card card-glow" style="text-align:center;padding:var(--space-6);">
        <div class="health-ring" style="margin:0 auto var(--space-4);">
          ${createRingProgress(health.overall, 100, 160, 10)}
          <div class="ring-label">
            <div class="ring-score text-gradient">${health.overall}</div>
            <div class="ring-text">Health Score</div>
          </div>
        </div>
        <div style="display:flex;justify-content:center;gap:var(--space-4);flex-wrap:wrap;">
          <div class="badge ${health.trend >= 0 ? 'badge-green' : 'badge-coral'}">
            ${health.trend >= 0 ? icons.trending : icons.trendingDown}
            <span>${health.trend >= 0 ? '+' : ''}${health.trend} this week</span>
          </div>
          <div class="badge badge-purple">
            <span>Grade: ${health.grade}</span>
          </div>
        </div>
        </div>
      </div>

      <!-- Quick Stats Row -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-3);margin-bottom:var(--space-6);">
        <!-- Daily Steps Card -->
        <div class="card card-sm step-card" onclick="location.hash='#/step-details'" style="margin-bottom:0;">
          <div class="step-ring-container">
            ${createRingProgress(data.stepHistory?.[0]?.value || 0, data.healthKit?.goal || 10000, 60, 6, 'var(--accent-teal)')}
            <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:18px;">${icons.steps}</div>
          </div>
          <div class="step-card-info">
            <h4>Steps</h4>
            <div class="step-card-value">${(data.stepHistory?.[0]?.value || 0).toLocaleString()}</div>
          </div>
        </div>

        <!-- Oura Hub Card -->
        <div class="card card-sm oura-card" style="margin-bottom:0;" onclick="location.hash='#/profile'">
          <div class="oura-hub-header">
            <div class="oura-ring-icon">${icons.ring}</div>
            <div class="oura-sync-status">${ouraConnected ? 'Synced' : 'Off'}</div>
          </div>
          ${ouraConnected ? `
            <div class="oura-scores-grid">
              <div class="oura-score-item">
                <div class="oura-score-value">${latestReadiness}</div>
                <div class="oura-score-label">Readiness</div>
              </div>
              <div class="oura-score-item">
                <div class="oura-score-value">${latestSleep}</div>
                <div class="oura-score-label">Sleep</div>
              </div>
            </div>
          ` : `
            <button class="oura-connect-btn">Connect Oura</button>
          `}
        </div>
      </div>

      <!-- Quick Actions Grid -->
      <div class="section-heading">
        <h3>Quick Actions</h3>
      </div>
      <div class="grid-3" style="margin-bottom:var(--space-6);">
        <div class="quick-action" onclick="location.hash='#/food-scanner'">
          <div class="action-icon" style="background:var(--accent-teal-dim);">🍎</div>
          <span class="action-label">Scan Food</span>
        </div>
        <div class="quick-action" onclick="location.hash='#/body-scanner'">
          <div class="action-icon" style="background:var(--accent-purple-dim);">🔬</div>
          <span class="action-label">Body Scan</span>
        </div>
        <div class="quick-action" onclick="location.hash='#/stool-scanner'">
          <div class="action-icon" style="background:var(--accent-amber-dim);">🧪</div>
          <span class="action-label">Stool Check</span>
        </div>
        <div class="quick-action" onclick="location.hash='#/health-input'">
          <div class="action-icon" style="background:var(--accent-blue-dim);">📋</div>
          <span class="action-label">Log Data</span>
        </div>
        <div class="quick-action" onclick="location.hash='#/eastern-medicine'">
          <div class="action-icon" style="background:var(--accent-coral-dim);">🧘</div>
          <span class="action-label">Ayurveda</span>
        </div>
        <div class="quick-action" onclick="location.hash='#/analytics'">
          <div class="action-icon" style="background:var(--accent-green-dim);">📊</div>
          <span class="action-label">Analytics</span>
        </div>
      </div>

      <!-- Daily Nutrition Summary -->
      <div class="section-heading">
        <h3>Today's Nutrition</h3>
        <span class="see-all" onclick="location.hash='#/food-scanner'">View All</span>
      </div>
      <div class="card" style="margin-bottom:var(--space-6);">
        <div style="display:flex;justify-content:space-between;margin-bottom:var(--space-4);">
          ${renderMacro('Calories', data.dailyNutrition?.calories || 1847, 2200, 'kcal', 'var(--accent-teal)')}
          ${renderMacro('Protein', data.dailyNutrition?.protein || 82, 120, 'g', 'var(--accent-blue)')}
          ${renderMacro('Carbs', data.dailyNutrition?.carbs || 195, 250, 'g', 'var(--accent-amber)')}
          ${renderMacro('Fat', data.dailyNutrition?.fat || 64, 75, 'g', 'var(--accent-coral)')}
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width:${Math.min(100, Math.round(((data.dailyNutrition?.calories || 1847) / 2200) * 100))}%"></div>
        </div>
        <p style="font-size:var(--text-xs);color:var(--text-tertiary);margin-top:var(--space-2);text-align:center;">
          ${2200 - (data.dailyNutrition?.calories || 1847)} kcal remaining today
        </p>
      </div>

      <!-- Health Trend -->
      <div class="section-heading">
        <h3>Weekly Trend</h3>
        <span class="see-all" onclick="location.hash='#/analytics'">Details</span>
      </div>
      <div class="card" style="margin-bottom:var(--space-6);">
        <div style="margin-bottom:var(--space-2);display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:var(--text-sm);color:var(--text-secondary);">Health Score</span>
          <span class="badge badge-green" style="font-size:var(--text-xs);">
            ${icons.trending} +${Math.abs(health.trend)} pts
          </span>
        </div>
        ${createLineChart(data.weeklyScores || [72, 74, 71, 76, 78, 75, 78], 340, 80)}
        <div style="display:flex;justify-content:space-between;margin-top:var(--space-2);">
          ${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => `<span style="font-size:var(--text-xs);color:var(--text-tertiary);">${d}</span>`).join('')}
        </div>
      </div>

      <!-- Insights -->
      <div class="section-heading">
        <h3>Insights & Tips</h3>
      </div>
      <div style="display:flex;flex-direction:column;gap:var(--space-3);margin-bottom:var(--space-6);">
        ${insights.slice(0, 3).map(insight => `
          <div class="card card-sm">
            <div class="insight-card">
              <div class="insight-icon" style="background:${insight.color}22;">
                <span>${insight.icon}</span>
              </div>
              <div class="insight-content">
                <h4>${insight.title}</h4>
                <p>${insight.text}</p>
              </div>
            </div>
          </div>
        `).join('')}
      </div>

      <!-- Recent Activity -->
      <div class="section-heading">
        <h3>Recent Activity</h3>
      </div>
      <div class="card" style="margin-bottom:var(--space-6);">
        ${renderRecentActivity(data)}
      </div>

      <!-- Streaks -->
      <div class="section-heading">
        <h3>Your Streaks</h3>
      </div>
      <div class="grid-3" style="margin-bottom:var(--space-8);">
        ${renderStreak('🔥', 'Logging', data.streaks?.logging || 7, 'var(--accent-coral)')}
        ${renderStreak('💪', 'Exercise', data.streaks?.exercise || 4, 'var(--accent-blue)')}
        ${renderStreak('😴', 'Sleep', data.streaks?.sleep || 5, 'var(--accent-purple)')}
      </div>
    </div>
  `;
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return '☀️ Good morning';
  if (h < 17) return '🌤️ Good afternoon';
  return '🌙 Good evening';
}

function renderMacro(label, value, target, unit, color) {
  const pct = Math.min(100, Math.round((value / target) * 100));
  return `
    <div style="text-align:center;flex:1;">
      <div style="font-family:var(--font-heading);font-size:var(--text-md);font-weight:var(--weight-bold);color:${color};">${value}</div>
      <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${label}</div>
      <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${pct}%</div>
    </div>
  `;
}

function renderRecentActivity(data) {
  const activities = [
    { icon: '🍎', bg: 'var(--accent-teal-dim)', title: 'Food Scan', detail: 'Grilled Chicken Salad', time: '2 hours ago', value: '435 kcal' },
    { icon: '🏃', bg: 'var(--accent-blue-dim)', title: 'Exercise Logged', detail: 'Morning Run — 5.2 km', time: '6 hours ago', value: '320 kcal' },
    { icon: '😴', bg: 'var(--accent-purple-dim)', title: 'Sleep Tracked', detail: '7.5 hours • 86% quality', time: '10 hours ago', value: '86%' },
    { icon: '🧪', bg: 'var(--accent-amber-dim)', title: 'Lab Results', detail: 'Vitamin D panel updated', time: 'Yesterday', value: 'Updated' },
  ];

  return activities.map(a => `
    <div class="activity-item">
      <div class="activity-icon" style="background:${a.bg};">${a.icon}</div>
      <div class="activity-text">
        <div class="title">${a.title}</div>
        <div class="time">${a.detail} • ${a.time}</div>
      </div>
      <div class="activity-value" style="color:var(--accent-teal);">${a.value}</div>
    </div>
  `).join('<div class="divider" style="margin:0;"></div>');
}

function renderStreak(emoji, label, count, color) {
  return `
    <div class="card card-sm" style="text-align:center;">
      <div style="font-size:24px;margin-bottom:var(--space-1);">${emoji}</div>
      <div style="font-family:var(--font-heading);font-size:var(--text-xl);font-weight:var(--weight-bold);color:${color};">${count}</div>
      <div style="font-size:var(--text-xs);color:var(--text-tertiary);">${label} days</div>
    </div>
  `;
}
