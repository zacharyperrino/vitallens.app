// ─── Product Results Page ────────────────────────────────────
// Displays detailed product analysis: score badge, nutrition table,
// ingredients with flagged additives, and positives/negatives.

import { store } from '../store.js';
import { icons } from '../icons.js';
import { getScoreColor, getScoreLabel } from '../utils/product-scanner.js';
import { createDonutChart } from '../utils/charts.js';

/**
 * Render product detail results.
 * Called with product data stored in sessionStorage or passed via hash params.
 */
export function renderProductResults() {
  const content = document.getElementById('page-content');
  const data = window._lastProductScan;

  if (!data) {
    content.innerHTML = `
      <div class="food-scanner stagger-children">
        <div class="card" style="text-align:center;padding:var(--space-8);">
          <div style="font-size:48px;margin-bottom:var(--space-3);">🔍</div>
          <h3>No Product Data</h3>
          <p style="font-size:var(--text-sm);color:var(--text-secondary);">Scan a product barcode to see results here.</p>
          <button class="btn btn-primary" onclick="location.hash='#/food-scanner'" style="margin-top:var(--space-4);">Go to Scanner</button>
        </div>
      </div>`;
    return;
  }

  const { product, healthScore, additives } = data;
  const n = product.nutrition || {};
  const score = healthScore.score;
  const scoreColor = healthScore.color || getScoreColor(score);
  const scoreLabel = healthScore.rating || getScoreLabel(score);

  // Macro percentages for chart
  const totalMacro = Math.round(((n.protein || 0) + (n.carbs || 0) + (n.fat || 0)) * 10) / 10;
  const pPct = totalMacro ? Math.round(((n.protein || 0) / totalMacro) * 100) : 0;
  const cPct = totalMacro ? Math.round(((n.carbs || 0) / totalMacro) * 100) : 0;
  const fPct = totalMacro ? 100 - pPct - cPct : 0;

  // Flag ingredients with additives
  const flaggedIngredients = highlightAdditives(product.ingredients, additives?.analyzed || []);

  content.innerHTML = `
    <div class="food-scanner stagger-children">
      <!-- Back Button -->
      <div style="display:flex;align-items:center;gap:var(--space-2);margin-bottom:var(--space-4);cursor:pointer;" onclick="location.hash='#/food-scanner'">
        <span style="color:var(--text-tertiary);transform:rotate(180deg);display:inline-block;">${icons.chevronRight}</span>
        <span style="font-size:var(--text-sm);color:var(--text-tertiary);">Back to Scanner</span>
      </div>

      <!-- Product Header + Score Badge -->
      <div class="card product-header-card">
        <div style="display:flex;gap:var(--space-4);align-items:center;">
          <div class="product-score-badge" style="--score-color:${scoreColor};">
            <div class="product-score-value">${score}</div>
            <div class="product-score-label">${scoreLabel}</div>
          </div>
          <div style="flex:1;">
            <h2 style="font-size:var(--text-lg);margin-bottom:var(--space-1);">${product.name}</h2>
            ${product.brand ? `<p style="font-size:var(--text-sm);color:var(--text-secondary);">${product.brand}</p>` : ''}
            <div style="display:flex;gap:var(--space-2);margin-top:var(--space-2);flex-wrap:wrap;">
              ${product.nutriscore ? `<span class="badge" style="background:${getNutriScoreColor(product.nutriscore)};color:white;">NutriScore ${product.nutriscore}</span>` : ''}
              ${product.nova_group ? `<span class="badge badge-${product.nova_group <= 2 ? 'green' : product.nova_group <= 3 ? 'amber' : 'coral'}">NOVA ${product.nova_group}</span>` : ''}
            </div>
          </div>
        </div>
      </div>

      <!-- Positives & Negatives -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--space-3);">
        <div class="card" style="border-left:3px solid #4CAF50;">
          <h4 style="font-size:var(--text-xs);color:#4CAF50;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:var(--space-2);">✓ Positives</h4>
          ${(healthScore.positives || []).map(p => `<p style="font-size:var(--text-xs);color:var(--text-secondary);margin-bottom:var(--space-1);">• ${p}</p>`).join('') || '<p style="font-size:var(--text-xs);color:var(--text-tertiary);">—</p>'}
        </div>
        <div class="card" style="border-left:3px solid #F44336;">
          <h4 style="font-size:var(--text-xs);color:#F44336;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:var(--space-2);">✗ Negatives</h4>
          ${(healthScore.negatives || []).map(n => `<p style="font-size:var(--text-xs);color:var(--text-secondary);margin-bottom:var(--space-1);">• ${n}</p>`).join('') || '<p style="font-size:var(--text-xs);color:var(--text-tertiary);">—</p>'}
        </div>
      </div>

      <!-- Nutrition per 100g -->
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-4);">
          <h4>Nutrition per 100g</h4>
          <span style="font-family:var(--font-heading);font-size:var(--text-2xl);font-weight:var(--weight-extrabold);color:var(--accent-teal);">${n.calories || '—'} <span style="font-size:var(--text-xs);font-weight:var(--weight-normal);color:var(--text-tertiary);">kcal</span></span>
        </div>
        <div style="display:flex;align-items:center;gap:var(--space-5);">
          <div class="chart-container" style="flex-shrink:0;">
            ${totalMacro > 0 ? createDonutChart([
    { percent: pPct, color: 'var(--accent-blue)' },
    { percent: cPct, color: 'var(--accent-amber)' },
    { percent: fPct, color: 'var(--accent-coral)' },
  ], 100, 10) : '<div style="width:100px;height:100px;border-radius:50%;background:var(--surface-2);display:flex;align-items:center;justify-content:center;font-size:var(--text-xs);color:var(--text-tertiary);">N/A</div>'}
            ${totalMacro > 0 ? `<div class="chart-center-label"><div class="value" style="font-size:var(--text-md);">${totalMacro}g</div><div class="label">total</div></div>` : ''}
          </div>
          <div style="flex:1;">
            ${renderNutrientRow('Protein', n.protein, 'g', pPct, 'var(--accent-blue)')}
            ${renderNutrientRow('Carbs', n.carbs, 'g', cPct, 'var(--accent-amber)')}
            ${renderNutrientRow('  ↳ Sugar', n.sugar, 'g', null, 'var(--accent-coral)')}
            ${renderNutrientRow('Fat', n.fat, 'g', fPct, 'var(--accent-coral)')}
            ${renderNutrientRow('  ↳ Sat. Fat', n.saturated_fat, 'g', null, '#e57373')}
            ${renderNutrientRow('Fiber', n.fiber, 'g', null, 'var(--accent-green)')}
            ${renderNutrientRow('Sodium', n.sodium, 'mg', null, 'var(--text-secondary)')}
          </div>
        </div>
      </div>

      <!-- Ingredients & Additives -->
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:var(--space-3);cursor:pointer;" id="ingredients-toggle">
          <h4>Ingredients</h4>
          <span style="color:var(--text-tertiary);font-size:var(--text-xs);">${icons.chevronRight}</span>
        </div>
        <div id="ingredients-body" class="expandable-section" style="display:none;">
          <p style="font-size:var(--text-sm);color:var(--text-secondary);line-height:1.6;">${flaggedIngredients || '<em>Not available</em>'}</p>
        </div>
      </div>

      <!-- Additive Analysis -->
      ${additives && additives.analyzed && additives.analyzed.length > 0 ? `
      <div class="card">
        <h4 style="margin-bottom:var(--space-3);">Additives (${additives.summary?.total || additives.analyzed.length})</h4>
        <div style="display:flex;gap:var(--space-2);margin-bottom:var(--space-3);flex-wrap:wrap;">
          ${additives.summary?.high > 0 ? `<span class="badge badge-coral">${additives.summary.high} high risk</span>` : ''}
          ${additives.summary?.moderate > 0 ? `<span class="badge badge-amber">${additives.summary.moderate} moderate</span>` : ''}
          ${additives.summary?.low > 0 ? `<span class="badge badge-green">${additives.summary.low} low risk</span>` : ''}
        </div>
        ${additives.analyzed.map(a => `
          <div class="additive-row additive-${a.risk_level}">
            <div style="display:flex;align-items:center;gap:var(--space-2);">
              <span class="additive-risk-dot additive-dot-${a.risk_level}"></span>
              <span style="font-weight:var(--weight-semibold);font-size:var(--text-sm);">${a.code}</span>
              <span style="font-size:var(--text-sm);color:var(--text-secondary);">${a.name}</span>
            </div>
            <span class="badge badge-${a.risk_level === 'high' ? 'coral' : a.risk_level === 'moderate' ? 'amber' : 'green'}" style="font-size:10px;">${a.risk_level}</span>
          </div>
        `).join('')}
      </div>
      ` : ''}

      <!-- Disclaimer -->
      <p style="font-size:var(--text-xs);color:var(--text-tertiary);text-align:center;padding:var(--space-3) var(--space-4);line-height:1.5;">
        ⚠️ This score is for informational purposes and does not constitute medical or dietary advice.
        Data sourced from Open Food Facts. Always consult a healthcare professional.
      </p>
    </div>
  `;

  // Setup toggle
  setupExpandables();
}

function renderNutrientRow(label, value, unit, pct, color) {
  const displayValue = value != null ? `${value}${unit}` : '—';
  return `
    <div class="nutrient-row" style="padding:var(--space-1) 0;">
      <div class="nutrient-info">
        <div class="nutrient-dot" style="background:${color};"></div>
        <span class="nutrient-name">${label}</span>
      </div>
      <span class="nutrient-value">${displayValue}${pct != null ? ` (${pct}%)` : ''}</span>
    </div>`;
}

function highlightAdditives(ingredientsText, analyzed) {
  if (!ingredientsText) return '';
  let html = ingredientsText;
  for (const a of analyzed) {
    const regex = new RegExp(`(${a.code})`, 'gi');
    const cls = a.risk_level === 'high' ? 'additive-flag-high' : a.risk_level === 'moderate' ? 'additive-flag-moderate' : '';
    if (cls) {
      html = html.replace(regex, `<span class="${cls}" title="${a.name} — ${a.risk_level} risk">$1</span>`);
    }
  }
  return html;
}

function getNutriScoreColor(grade) {
  const colors = { A: '#038141', B: '#85BB2F', C: '#FECB02', D: '#EE8100', E: '#E63E11' };
  return colors[grade?.toUpperCase()] || '#888';
}

function setupExpandables() {
  document.getElementById('ingredients-toggle')?.addEventListener('click', () => {
    const body = document.getElementById('ingredients-body');
    if (body) {
      const isOpen = body.style.display !== 'none';
      body.style.display = isOpen ? 'none' : 'block';
    }
  });
}
